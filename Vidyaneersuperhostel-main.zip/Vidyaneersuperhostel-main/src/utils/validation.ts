import { z } from 'zod';
import type { BookingRecord, DashboardStats, InquiryRecord, Room } from '../types/hostel';

export const BD_MOBILE_REGEX = /^01[3-9][0-9]{8}$/;

export function normalizeBdMobile(raw: string): string {
  const digits = raw.replace(/[\s\-()]/g, '');
  if (digits.startsWith('+880')) {
    return '0' + digits.slice(4);
  }
  if (digits.startsWith('880') && digits.length === 13) {
    return '0' + digits.slice(3);
  }
  return digits;
}

export function isValidBdMobile(raw: string): boolean {
  return BD_MOBILE_REGEX.test(normalizeBdMobile(raw));
}

export function formatWhatsAppUrl(phone: string, prefill?: string): string {
  const normalized = normalizeBdMobile(phone);
  const international = normalized.startsWith('0') ? `88${normalized}` : normalized;
  if (prefill) {
    return `https://wa.me/${international}?text=${encodeURIComponent(prefill)}`;
  }
  return `https://wa.me/${international}`;
}

export function formatTelUrl(phone: string): string {
  const normalized = normalizeBdMobile(phone);
  return `tel:+88${normalized}`;
}

export const bookingFormSchema = z.object({
  studentName: z.string().trim().min(2, 'Student name must be at least 2 characters').max(120),
  mobile: z
    .string()
    .trim()
    .transform(normalizeBdMobile)
    .refine((val) => BD_MOBILE_REGEX.test(val), 'Enter a valid 11-digit BD mobile number (01XXXXXXXXX)'),
  guardianMobile: z
    .string()
    .trim()
    .transform(normalizeBdMobile)
    .refine((val) => BD_MOBILE_REGEX.test(val), 'Enter a valid 11-digit guardian mobile number'),
  institution: z.string().trim().min(2, 'Enter college or university name').max(160),
  roomId: z.string().trim().min(1, 'Please select a room category').max(128),
  occupants: z.coerce.number().int().min(1, 'Minimum 1 occupant').max(10, 'Maximum 10 occupants'),
  preferredDate: z
    .string()
    .trim()
    .regex(/^\d{4}-\d{2}-\d{2}$/, 'Select a valid move-in date (YYYY-MM-DD)'),
  message: z.string().trim().max(800).optional().default(''),
});

export type BookingFormInput = z.infer<typeof bookingFormSchema>;

export const inquiryFormSchema = z.object({
  senderName: z.string().trim().min(2, 'Name must be at least 2 characters').max(120),
  phone: z
    .string()
    .trim()
    .transform(normalizeBdMobile)
    .refine((val) => BD_MOBILE_REGEX.test(val), 'Enter a valid 11-digit BD mobile number (01XXXXXXXXX)'),
  subject: z.string().trim().min(2, 'Subject is required').max(160),
  message: z.string().trim().min(5, 'Message must be at least 5 characters').max(1000),
});

export type InquiryFormInput = z.infer<typeof inquiryFormSchema>;

export function generateBookingCode(year = new Date().getFullYear()): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let suffix = '';
  for (let i = 0; i < 6; i += 1) {
    suffix += chars[Math.floor(Math.random() * chars.length)];
  }
  return `BH-${year}-${suffix}`;
}

export function createSubmissionSignature(mobile: string, roomId: string, preferredDate: string): string {
  return `${normalizeBdMobile(mobile)}::${roomId}::${preferredDate}`;
}

export function validateRoomAvailabilityForBooking(
  room: Room | undefined,
  occupants: number
): { ok: boolean; reason?: 'not_found' | 'unavailable' | 'insufficient_seats' } {
  if (!room) {
    return { ok: false, reason: 'not_found' };
  }
  if (room.availabilityStatus === 'full' || room.availabilityStatus === 'maintenance') {
    return { ok: false, reason: 'unavailable' };
  }
  if (room.availableSeats < occupants) {
    return { ok: false, reason: 'insufficient_seats' };
  }
  return { ok: true };
}

export function computeDashboardStats(
  rooms: Room[],
  bookings: BookingRecord[],
  inquiries: InquiryRecord[]
): DashboardStats {
  const totalRooms = rooms.length;
  const totalCapacity = rooms.reduce((sum, r) => sum + Math.max(0, r.capacity), 0);
  const availableSeats = rooms.reduce((sum, r) => sum + Math.max(0, r.availableSeats), 0);
  const occupiedSeats = Math.max(0, totalCapacity - availableSeats);

  const availableRooms = rooms.filter(
    (r) => (r.availabilityStatus === 'available' || r.availabilityStatus === 'limited') && r.availableSeats > 0
  ).length;
  const occupiedRooms = rooms.filter(
    (r) => r.availabilityStatus === 'full' || r.availableSeats === 0
  ).length;

  const pendingBookings = bookings.filter((b) => b.status === 'pending').length;
  const approvedBookings = bookings.filter((b) => b.status === 'approved').length;
  const totalInquiries = inquiries.length;

  return {
    totalRooms,
    totalCapacity,
    availableSeats,
    occupiedSeats,
    availableRooms,
    occupiedRooms,
    pendingBookings,
    approvedBookings,
    totalInquiries,
  };
}

export function getNarsingdiMapsSearchUrl(): string {
  return 'https://www.google.com/maps/search/?api=1&query=Narsingdi+Government+College,+Narsingdi,+Bangladesh';
}
