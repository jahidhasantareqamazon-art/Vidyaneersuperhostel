import test from 'node:test';
import assert from 'node:assert/strict';
import {
  bookingFormSchema,
  computeDashboardStats,
  createSubmissionSignature,
  formatTelUrl,
  formatWhatsAppUrl,
  generateBookingCode,
  inquiryFormSchema,
  isValidBdMobile,
  normalizeBdMobile,
  validateRoomAvailabilityForBooking,
} from './validation';
import type { BookingRecord, InquiryRecord, Room } from '../types/hostel';

test('normalizeBdMobile normalizes +880, 880, spaces, and dashes cleanly', () => {
  assert.equal(normalizeBdMobile('+880 1928-949055'), '01928949055');
  assert.equal(normalizeBdMobile('01671-948750'), '01671948750');
  assert.equal(normalizeBdMobile('8801671948750'), '01671948750');
  assert.equal(normalizeBdMobile('01928 949 055'), '01928949055');
  assert.equal(isValidBdMobile('01928949055'), true);
  assert.equal(isValidBdMobile('01671-948750'), true);
  assert.equal(isValidBdMobile('01234567890'), false);
  assert.equal(isValidBdMobile('12345'), false);
});

test('formatWhatsAppUrl and formatTelUrl produce exact Bangladesh links', () => {
  assert.equal(formatWhatsAppUrl('01928-949055'), 'https://wa.me/8801928949055');
  assert.equal(formatWhatsAppUrl('01671-948750'), 'https://wa.me/8801671948750');
  assert.equal(formatTelUrl('01928-949055'), 'tel:+8801928949055');
  assert.equal(formatTelUrl('01671-948750'), 'tel:+8801671948750');
});

test('bookingFormSchema validates valid payloads and rejects invalid BD phone numbers', () => {
  const valid = bookingFormSchema.safeParse({
    studentName: 'Tariqul Islam',
    mobile: '+8801783807171',
    guardianMobile: '01522136035',
    institution: 'Narsingdi Govt. College',
    roomId: 'room-single',
    occupants: 1,
    preferredDate: '2026-12-01',
    message: 'Need quiet study room',
  });
  assert.equal(valid.success, true);
  if (valid.success) {
    assert.equal(valid.data.mobile, '01783807171');
  }

  const invalid = bookingFormSchema.safeParse({
    studentName: 'A',
    mobile: '00000',
    guardianMobile: '01522136035',
    institution: 'N',
    roomId: '',
    occupants: 0,
    preferredDate: 'invalid',
  });
  assert.equal(invalid.success, false);
});

test('inquiryFormSchema validates contact inquiries', () => {
  const ok = inquiryFormSchema.safeParse({
    senderName: 'Karim Uddin',
    phone: '01783807171',
    subject: 'Seat availability inquiry',
    message: 'Are single rooms available for HSC batch?',
  });
  assert.equal(ok.success, true);

  const bad = inquiryFormSchema.safeParse({
    senderName: 'K',
    phone: '123',
    subject: 'Hi',
    message: 'ok',
  });
  assert.equal(bad.success, false);
});

test('generateBookingCode creates unique BH-YYYY-XXXXXX codes', () => {
  const code = generateBookingCode(2026);
  assert.match(code, /^BH-2026-[A-Z0-9]{6}$/);
});

test('validateRoomAvailabilityForBooking checks status and seat count', () => {
  const sampleRoom: Room = {
    id: 'room-double',
    category: 'double',
    titleBn: 'ডাবল শেয়ারিং রুম',
    titleEn: 'Double Sharing Room',
    descriptionBn: 'দুইজনের জন্য রুম',
    descriptionEn: 'Two-person sharing room',
    capacity: 2,
    availableSeats: 2,
    monthlyRent: null,
    priceConfirmed: false,
    pricePlaceholderBn: 'যোগাযোগ সাপেক্ষে',
    pricePlaceholderEn: 'Contact for Fee',
    availabilityStatus: 'available',
    facilitiesBn: [],
    facilitiesEn: [],
    primaryImage: '/img.jpg',
    sortOrder: 2,
    updatedAt: '2026-11-15T00:00:00.000Z',
  };

  assert.deepEqual(validateRoomAvailabilityForBooking(sampleRoom, 2), { ok: true });
  assert.deepEqual(validateRoomAvailabilityForBooking(sampleRoom, 3), {
    ok: false,
    reason: 'insufficient_seats',
  });
  assert.deepEqual(
    validateRoomAvailabilityForBooking({ ...sampleRoom, availabilityStatus: 'full' }, 1),
    { ok: false, reason: 'unavailable' }
  );
  assert.deepEqual(validateRoomAvailabilityForBooking(undefined, 1), {
    ok: false,
    reason: 'not_found',
  });
});

test('computeDashboardStats computes exact room and booking totals', () => {
  const rooms: Room[] = [
    {
      id: 'r1',
      category: 'single',
      titleBn: 'সিঙ্গেল',
      titleEn: 'Single',
      descriptionBn: 'desc',
      descriptionEn: 'desc',
      capacity: 4,
      availableSeats: 2,
      monthlyRent: null,
      priceConfirmed: false,
      pricePlaceholderBn: 'যোগাযোগ সাপেক্ষে',
      pricePlaceholderEn: 'Contact',
      availabilityStatus: 'available',
      facilitiesBn: [],
      facilitiesEn: [],
      primaryImage: '/a.jpg',
      sortOrder: 1,
      updatedAt: '2026-11-15T00:00:00Z',
    },
    {
      id: 'r2',
      category: 'double',
      titleBn: 'ডাবল',
      titleEn: 'Double',
      descriptionBn: 'desc',
      descriptionEn: 'desc',
      capacity: 6,
      availableSeats: 0,
      monthlyRent: null,
      priceConfirmed: false,
      pricePlaceholderBn: 'যোগাযোগ সাপেক্ষে',
      pricePlaceholderEn: 'Contact',
      availabilityStatus: 'full',
      facilitiesBn: [],
      facilitiesEn: [],
      primaryImage: '/b.jpg',
      sortOrder: 2,
      updatedAt: '2026-11-15T00:00:00Z',
    },
  ];
  const bookings: BookingRecord[] = [
    {
      id: 'b1',
      bookingCode: 'BH-2026-AAA111',
      studentName: 'S1',
      mobile: '01783807171',
      guardianMobile: '01522136035',
      institution: 'NGC',
      roomId: 'r1',
      roomType: 'Single',
      occupants: 1,
      preferredDate: '2026-12-01',
      status: 'pending',
      createdAt: '2026-11-15T00:00:00Z',
      updatedAt: '2026-11-15T00:00:00Z',
    },
    {
      id: 'b2',
      bookingCode: 'BH-2026-BBB222',
      studentName: 'S2',
      mobile: '01783807171',
      guardianMobile: '01522136035',
      institution: 'NGC',
      roomId: 'r1',
      roomType: 'Single',
      occupants: 1,
      preferredDate: '2026-12-02',
      status: 'approved',
      createdAt: '2026-11-15T00:00:00Z',
      updatedAt: '2026-11-15T00:00:00Z',
    },
  ];
  const inquiries: InquiryRecord[] = [
    {
      id: 'i1',
      senderName: 'Guardian',
      phone: '01783807171',
      subject: 'Question',
      message: 'Hello there',
      status: 'new',
      createdAt: '2026-11-15T00:00:00Z',
    },
  ];

  const stats = computeDashboardStats(rooms, bookings, inquiries);
  assert.equal(stats.totalRooms, 2);
  assert.equal(stats.availableRooms, 1);
  assert.equal(stats.occupiedRooms, 1);
  assert.equal(stats.availableSeats, 2);
  assert.equal(stats.occupiedSeats, 8);
  assert.equal(stats.pendingBookings, 1);
  assert.equal(stats.approvedBookings, 1);
  assert.equal(stats.totalInquiries, 1);
  assert.equal(createSubmissionSignature('+8801783807171', 'r1', '2026-12-01'), '01783807171::r1::2026-12-01');
});
