import type { Language } from '../types/hostel';

export interface CopyBundle {
  nav: {
    home: string;
    about: string;
    rooms: string;
    facilities: string;
    gallery: string;
    contact: string;
    bookRoom: string;
    adminPortal: string;
  };
  hero: {
    locationTag: string;
    ctaBook: string;
    ctaContact: string;
    ctaRooms: string;
    statsRoomsLabel: string;
    statsSeatsLabel: string;
    statsLocationLabel: string;
    statsLocationValue: string;
    statsSupportLabel: string;
    statsSupportValue: string;
  };
  about: {
    kicker: string;
    title: string;
    locationAdvantageTitle: string;
    locationAdvantageBody: string;
    studentFocusTitle: string;
    studentFocusBody: string;
    whyTitle: string;
    whySubtitle: string;
    reasons: { title: string; body: string }[];
  };
  rooms: {
    kicker: string;
    title: string;
    subtitle: string;
    capacityLabel: string;
    seatsLabel: string;
    monthlyRentLabel: string;
    perMonth: string;
    bookThisRoom: string;
    viewDetails: string;
    statusLabels: {
      available: string;
      limited: string;
      full: string;
      maintenance: string;
    };
    categoryAll: string;
    categorySingle: string;
    categoryDouble: string;
    categoryMultiple: string;
  };
  facilities: {
    kicker: string;
    title: string;
    subtitle: string;
    confirmedLabel: string;
    pendingConfirmLabel: string;
  };
  gallery: {
    kicker: string;
    title: string;
    subtitle: string;
    all: string;
    rooms: string;
    building: string;
    common: string;
    facilities: string;
  };
  booking: {
    kicker: string;
    title: string;
    subtitle: string;
    noticePending: string;
    studentName: string;
    mobile: string;
    guardianMobile: string;
    institution: string;
    roomType: string;
    roomLabel: string;
    occupants: string;
    preferredDate: string;
    message: string;
    submitBtn: string;
    submitting: string;
    successTitle: string;
    successSubtitle: string;
    bookingIdLabel: string;
    currentStatusLabel: string;
    lookupTitle: string;
    lookupSubtitle: string;
    lookupPlaceholder: string;
    lookupBtn: string;
    lookupNotFound: string;
    statusLabels: {
      pending: string;
      approved: string;
      rejected: string;
      completed: string;
    };
  };
  testimonials: {
    kicker: string;
    title: string;
    emptyTitle: string;
    emptyBody: string;
  };
  location: {
    kicker: string;
    title: string;
    openGoogleMaps: string;
    nearbyLabel: string;
    nearbyPlaces: string[];
  };
  contact: {
    kicker: string;
    title: string;
    subtitle: string;
    callNow: string;
    whatsappChat: string;
    formTitle: string;
    senderName: string;
    phone: string;
    subject: string;
    message: string;
    sendInquiry: string;
    sending: string;
    inquirySuccess: string;
  };
  footer: {
    tagline: string;
    quickLinks: string;
    explore: string;
    directContact: string;
    rights: string;
  };
}

export const COPY: Record<Language, CopyBundle> = {
  bn: {
    nav: {
      home: 'হোম',
      about: 'আমাদের সম্পর্কে',
      rooms: 'রুমসমূহ',
      facilities: 'সুবিধাসমূহ',
      gallery: 'গ্যালারি',
      contact: 'যোগাযোগ',
      bookRoom: 'রুম বুকিং করুন',
      adminPortal: 'অ্যাডমিন পোর্টাল',
    },
    hero: {
      locationTag: 'নরসিংদী সরকারি কলেজ সংলগ্ন · উদয়ন কলেজের পেছনে',
      ctaBook: 'রুম বুকিং করুন',
      ctaContact: 'যোগাযোগ করুন',
      ctaRooms: 'রুম দেখুন',
      statsRoomsLabel: 'রুম ক্যাটাগরি',
      statsSeatsLabel: 'মোট আসন উপলব্ধ',
      statsLocationLabel: 'অবস্থান',
      statsLocationValue: 'কলেজ সংলগ্ন',
      statsSupportLabel: 'সরাসরি যোগাযোগ',
      statsSupportValue: '০১৯২৮-৯৪৯০৫৫',
    },
    about: {
      kicker: 'বিদ্যা নীড় সুপার হোস্টেল পরিচিতি',
      title: 'শিক্ষার্থীদের নিরাপদ আবাসন ও অধ্যয়নের বিশ্বস্ত ঠিকানা',
      locationAdvantageTitle: 'কৌশলগত ও সুবিধাজনক অবস্থান',
      locationAdvantageBody:
        'নরসিংদী সরকারি কলেজ সংলগ্ন এবং উদয়ন কলেজের ঠিক পেছনে অবস্থিত হওয়ায় শিক্ষার্থীরা হেঁটেই ক্লাস ও প্রাইভেট কোচিংয়ে যাতায়াত করতে পারেন।',
      studentFocusTitle: 'অভিভাবকদের জন্য নিশ্চিন্ত পরিবেশ',
      studentFocusBody:
        'সুশৃঙ্খল নিয়ম-কানুন, অভিভাবক যোগাযোগ ব্যবস্থা এবং পড়াশোনাবান্ধব আবহাওয়া শিক্ষার্থীদের একাডেমিক ফলাফলে সহায়ক ভূমিকা রাখে।',
      whyTitle: 'কেন বিদ্যা নীড় সুপার হোস্টেল বেছে নেবেন',
      whySubtitle: 'নিরাপত্তা, পরিচ্ছন্নতা এবং পড়াশোনার অনুকূল পরিবেশের সমন্বয়ে গঠিত আমাদের আবাসন ব্যবস্থা।',
      reasons: [
        {
          title: 'নিরাপদ পরিবেশ',
          body: 'নিয়ন্ত্রিত প্রবেশ ব্যবস্থা ও সার্বক্ষণিক তত্ত্বাবধানে শিক্ষার্থীদের নিরাপত্তা নিশ্চিত করা হয়।',
        },
        {
          title: 'আরামদায়ক রুম',
          body: 'আলো-বাতাসপূর্ণ পরিচ্ছন্ন রুম এবং প্রতিটি শিক্ষার্থীর জন্য আলাদা বিছানা ও পড়ার টেবিল।',
        },
        {
          title: 'শিক্ষার্থী-বান্ধব আবাসন',
          body: 'কলেজ ও বিশ্ববিদ্যালয়ের শিক্ষার্থীদের প্রয়োজন ও বাজেট অনুযায়ী রুম নির্বাচন করার সুবিধা।',
        },
        {
          title: 'সুবিধাজনক অবস্থান',
          body: 'নরসিংদী সরকারি কলেজ ও উদয়ন কলেজের একদম নিকটে হওয়ায় সময় ও যাতায়াত খরচ সাশ্রয় হয়।',
        },
        {
          title: 'পরিচ্ছন্ন পরিবেশ',
          body: 'নিয়মিত পরিষ্কার-পরিচ্ছন্নতা এবং স্বাস্থ্যসম্মত ওয়াশরুম ও কমন স্পেস ব্যবস্থাপনা।',
        },
        {
          title: 'সহায়ক ব্যবস্থাপনা',
          body: 'শিক্ষার্থী ও অভিভাবকদের যেকোনো প্রয়োজনে দ্রুত ও আন্তরিক সহায়তা প্রদান।',
        },
      ],
    },
    rooms: {
      kicker: 'আবাসন ও রুম ক্যাটাগরি',
      title: 'আপনার প্রয়োজন অনুযায়ী রুম বেছে নিন',
      subtitle: 'প্রতিটি রুমের আসন সংখ্যা, সুবিধাসমূহ এবং বর্তমান প্রাপ্যতা নিচে দেওয়া হলো।',
      capacityLabel: 'ধারণক্ষমতা',
      seatsLabel: 'ফাঁকা আসন',
      monthlyRentLabel: 'মাসিক ফি',
      perMonth: '/মাস',
      bookThisRoom: 'এই রুম বুকিং করুন',
      viewDetails: 'বিস্তারিত দেখুন',
      statusLabels: {
        available: 'আসন খালি আছে',
        limited: 'সীমিত আসন',
        full: 'আসন পূর্ণ',
        maintenance: 'সংস্কারাধীন',
      },
      categoryAll: 'সব রুম',
      categorySingle: 'সিঙ্গেল রুম',
      categoryDouble: 'ডাবল শেয়ারিং',
      categoryMultiple: 'মাল্টিপল শেয়ারিং',
    },
    facilities: {
      kicker: 'হোস্টেল সুবিধাসমূহ',
      title: 'শিক্ষার্থীদের দৈনন্দিন ও অধ্যয়নের প্রয়োজনীয় ব্যবস্থা',
      subtitle: 'নিশ্চিতকৃত মৌলিক সুবিধাসমূহ এবং প্রশাসকের অনুমোদন-নির্ভর অতিরিক্ত সুবিধার স্পষ্ট বিবরণ।',
      confirmedLabel: 'নিশ্চিতকৃত সুবিধা',
      pendingConfirmLabel: 'প্রশাসকের নিশ্চিতকরণ সাপেক্ষে',
    },
    gallery: {
      kicker: 'ফটো গ্যালারি',
      title: 'হোস্টেল ভবন ও রুমের বাস্তব পরিবেশ',
      subtitle: 'রুম, ভবন এবং কমন স্টাডি স্পেস ঘুরে দেখুন।',
      all: 'সকল ছবি',
      rooms: 'রুমসমূহ',
      building: 'ভবন',
      common: 'কমন স্পেস',
      facilities: 'সুবিধাসমূহ',
    },
    booking: {
      kicker: 'রুম বুকিং ও অনুসন্ধান',
      title: 'অনলাইনে সিট বুকিং আবেদন করুন',
      subtitle: 'সঠিক তথ্য দিয়ে ফর্মটি পূরণ করুন। প্রশাসক যাচাইয়ের পর আপনার বুকিং অনুমোদন করবেন।',
      noticePending: 'গুরুত্বপূর্ণ: আবেদন জমা দেওয়ার পর স্ট্যাটাস "অপেক্ষমান (Pending)" থাকবে। প্রশাসকের অনুমোদনের আগে বুকিং চূড়ান্ত হিসেবে গণ্য হবে না।',
      studentName: 'শিক্ষার্থীর পূর্ণ নাম',
      mobile: 'শিক্ষার্থীর মোবাইল নম্বর',
      guardianMobile: 'অভিভাবকের মোবাইল নম্বর',
      institution: 'কলেজ / বিশ্ববিদ্যালয়ের নাম',
      roomType: 'রুম ক্যাটাগরি নির্বাচন করুন',
      roomLabel: 'রুম ক্যাটাগরি',
      occupants: 'সদস্য সংখ্যা (আসন)',
      preferredDate: 'ওঠার সম্ভাব্য তারিখ',
      message: 'অতিরিক্ত বার্তা (ঐচ্ছিক)',
      submitBtn: 'বুকিং আবেদন জমা দিন',
      submitting: 'আবেদন জমা হচ্ছে...',
      successTitle: 'বুকিং আবেদন সফলভাবে গৃহীত হয়েছে',
      successSubtitle: 'আপনার আবেদনটি বর্তমানে প্রশাসকের পর্যালোচনার জন্য অপেক্ষমান রয়েছে।',
      bookingIdLabel: 'বুকিং আইডি',
      currentStatusLabel: 'বর্তমান অবস্থা',
      lookupTitle: 'বুকিং স্ট্যাটাস যাচাই করুন',
      lookupSubtitle: 'আপনার ইউনিক বুকিং আইডি দিয়ে আবেদনের সর্বশেষ অবস্থা দেখুন।',
      lookupPlaceholder: 'উদাহরণ: BH-2026-XXXXXX',
      lookupBtn: 'স্ট্যাটাস দেখুন',
      lookupNotFound: 'এই বুকিং আইডির কোনো তথ্য পাওয়া যায়নি।',
      statusLabels: {
        pending: 'অপেক্ষমান (Pending Approval)',
        approved: 'অনুমোদিত (Approved)',
        rejected: 'প্রত্যাখ্যাত (Rejected)',
        completed: 'সম্পন্ন (Completed)',
      },
    },
    testimonials: {
      kicker: 'শিক্ষার্থী ও অভিভাবকদের মতামত',
      title: 'যাচাইকৃত অভিজ্ঞতা ও মতামত',
      emptyTitle: 'প্রশাসক কর্তৃক যাচাইকৃত রিভিউ প্রকাশের অপেক্ষায়',
      emptyBody: 'আমরা কেবল প্রকৃত শিক্ষার্থী ও অভিভাবকদের অনুমোদিত মতামত প্রকাশ করি। কোনো বানোয়াট রিভিউ এখানে যুক্ত করা হয় না।',
    },
    location: {
      kicker: 'অবস্থান ও যাতায়াত',
      title: 'নরসিংদীর প্রাণকেন্দ্রে সহজ যাতায়াত',
      openGoogleMaps: 'গুগল ম্যাপে অবস্থান দেখুন',
      nearbyLabel: 'নিকটবর্তী শিক্ষাপ্রতিষ্ঠান ও এলাকা',
      nearbyPlaces: [
        'নরসিংদী সরকারি কলেজ (সংলগ্ন)',
        'উদয়ন কলেজ (ঠিক পেছনে)',
        'নরসিংদী সদর প্রধান সড়ক ও পরিবহন স্ট্যান্ড',
      ],
    },
    contact: {
      kicker: 'সরাসরি যোগাযোগ',
      title: 'যেকোনো তথ্যের জন্য আমাদের সাথে কথা বলুন',
      subtitle: 'ভর্তি, রুম প্রাপ্যতা বা পরিদর্শনের সময় নির্ধারণে কল অথবা হোয়াটসঅ্যাপ করুন।',
      callNow: 'সরাসরি কল করুন',
      whatsappChat: 'হোয়াটসঅ্যাপে বার্তা দিন',
      formTitle: 'অনুসন্ধান বার্তা পাঠান',
      senderName: 'আপনার নাম',
      phone: 'মোবাইল নম্বর',
      subject: 'বিষয়',
      message: 'আপনার বার্তা লিখুন',
      sendInquiry: 'বার্তা পাঠান',
      sending: 'পাঠানো হচ্ছে...',
      inquirySuccess: 'আপনার বার্তাটি সফলভাবে পাঠানো হয়েছে। আমাদের প্রতিনিধি শীঘ্রই যোগাযোগ করবেন।',
    },
    footer: {
      tagline: 'নরসিংদী সরকারি কলেজ সংলগ্ন নিরাপদ, পরিচ্ছন্ন ও অধ্যয়ন-বান্ধব শিক্ষার্থী আবাসন।',
      quickLinks: 'দ্রুত নেভিগেশন',
      explore: 'আরও দেখুন',
      directContact: 'সরাসরি যোগাযোগ',
      rights: 'সর্বস্বত্ব সংরক্ষিত।',
    },
  },
  en: {
    nav: {
      home: 'Home',
      about: 'About',
      rooms: 'Rooms',
      facilities: 'Facilities',
      gallery: 'Gallery',
      contact: 'Contact',
      bookRoom: 'Book a Room',
      adminPortal: 'Admin Portal',
    },
    hero: {
      locationTag: 'Adjacent to Narsingdi Govt. College · Behind Udayan College',
      ctaBook: 'Book a Room',
      ctaContact: 'Contact Us',
      ctaRooms: 'Explore Rooms',
      statsRoomsLabel: 'Room Categories',
      statsSeatsLabel: 'Seats Available',
      statsLocationLabel: 'Location',
      statsLocationValue: 'College Area',
      statsSupportLabel: 'Direct Helpline',
      statsSupportValue: '01928-949055',
    },
    about: {
      kicker: 'About Bidya Neer Super Hostel',
      title: 'A Trusted Residence Built for Student Safety & Focus',
      locationAdvantageTitle: 'Prime Academic Location',
      locationAdvantageBody:
        'Located right beside Narsingdi Government College and behind Udayan College, allowing students to walk to classes without daily commute stress.',
      studentFocusTitle: 'Peace of Mind for Parents',
      studentFocusBody:
        'Structured house rules, direct guardian communication, and a calm study-first environment help students stay disciplined and focused.',
      whyTitle: 'Why Choose Bidya Neer Super Hostel',
      whySubtitle: 'Every aspect of our facility prioritizes safety, cleanliness, and academic focus.',
      reasons: [
        {
          title: 'Safe Environment',
          body: 'Controlled access and attentive supervision ensure complete residential safety.',
        },
        {
          title: 'Comfortable Rooms',
          body: 'Well-ventilated, clean rooms equipped with individual beds and dedicated study desks.',
        },
        {
          title: 'Student-Friendly Accommodation',
          body: 'Flexible room tiers designed specifically for college and university students.',
        },
        {
          title: 'Convenient Location',
          body: 'Steps away from Narsingdi Govt. College and Udayan College for effortless commuting.',
        },
        {
          title: 'Clean Environment',
          body: 'Regular housekeeping across bedrooms, corridors, and shared washroom facilities.',
        },
        {
          title: 'Supportive Management',
          body: 'Responsive management available for both students and parents whenever needed.',
        },
      ],
    },
    rooms: {
      kicker: 'Accommodation & Room Categories',
      title: 'Choose the Room That Fits Your Study Routine',
      subtitle: 'Inspect room capacities, included facilities, and live availability.',
      capacityLabel: 'Capacity',
      seatsLabel: 'Available Seats',
      monthlyRentLabel: 'Monthly Rent',
      perMonth: '/month',
      bookThisRoom: 'Book This Room',
      viewDetails: 'View Details',
      statusLabels: {
        available: 'Available',
        limited: 'Limited Seats',
        full: 'Occupied / Full',
        maintenance: 'Maintenance',
      },
      categoryAll: 'All Rooms',
      categorySingle: 'Single Room',
      categoryDouble: 'Double Sharing',
      categoryMultiple: 'Multiple Sharing',
    },
    facilities: {
      kicker: 'Facilities & Amenities',
      title: 'Essential Infrastructure for Daily Living & Study',
      subtitle: 'Core verified amenities alongside optional services clearly marked pending admin confirmation.',
      confirmedLabel: 'Confirmed Facility',
      pendingConfirmLabel: 'Pending Admin Confirmation',
    },
    gallery: {
      kicker: 'Photo Gallery',
      title: 'Inside Bidya Neer Super Hostel',
      subtitle: 'Explore our building exterior, student rooms, and common study spaces.',
      all: 'All Photos',
      rooms: 'Rooms',
      building: 'Building',
      common: 'Common Spaces',
      facilities: 'Facilities',
    },
    booking: {
      kicker: 'Room Booking & Inquiry',
      title: 'Submit a Room Booking Request',
      subtitle: 'Complete the form with accurate student and guardian details. Bookings are finalized upon admin approval.',
      noticePending: 'Note: New submissions remain in "Pending" status until verified and approved by the hostel administrator.',
      studentName: 'Student Full Name',
      mobile: 'Student Mobile Number',
      guardianMobile: 'Guardian Mobile Number',
      institution: 'College / University',
      roomType: 'Select Room Category',
      roomLabel: 'Room Category',
      occupants: 'Number of Occupants',
      preferredDate: 'Preferred Move-in Date',
      message: 'Additional Message (Optional)',
      submitBtn: 'Submit Booking Request',
      submitting: 'Submitting Request...',
      successTitle: 'Booking Request Submitted',
      successSubtitle: 'Your request is currently pending administrator review and approval.',
      bookingIdLabel: 'Booking ID',
      currentStatusLabel: 'Current Status',
      lookupTitle: 'Check Booking Status',
      lookupSubtitle: 'Enter your unique Booking ID to verify your current approval status.',
      lookupPlaceholder: 'e.g. BH-2026-XXXXXX',
      lookupBtn: 'Check Status',
      lookupNotFound: 'No booking record found for that Booking ID.',
      statusLabels: {
        pending: 'Pending Admin Approval',
        approved: 'Approved',
        rejected: 'Rejected',
        completed: 'Completed',
      },
    },
    testimonials: {
      kicker: 'Student & Guardian Feedback',
      title: 'Verified Reviews & Testimonials',
      emptyTitle: 'Verified Testimonials Managed by Administration',
      emptyBody: 'We publish only authentic, administrator-verified feedback from residents and parents. No fabricated reviews are displayed.',
    },
    location: {
      kicker: 'Location & Directions',
      title: 'Centrally Located in Narsingdi',
      openGoogleMaps: 'Open in Google Maps',
      nearbyLabel: 'Immediate Vicinity',
      nearbyPlaces: [
        'Narsingdi Government College (Adjacent)',
        'Udayan College (Directly Behind)',
        'Narsingdi Sadar Main Road & Transit Access',
      ],
    },
    contact: {
      kicker: 'Direct Contact',
      title: 'Reach Our Hostel Office Directly',
      subtitle: 'Call or message via WhatsApp for seat availability, fees, or a campus visit.',
      callNow: 'Call Now',
      whatsappChat: 'WhatsApp Chat',
      formTitle: 'Send a Contact Inquiry',
      senderName: 'Your Name',
      phone: 'Mobile Number',
      subject: 'Subject',
      message: 'Your Message',
      sendInquiry: 'Send Inquiry',
      sending: 'Sending...',
      inquirySuccess: 'Your inquiry has been received. Our hostel administration will contact you shortly.',
    },
    footer: {
      tagline: 'Safe, clean, and study-friendly student accommodation adjacent to Narsingdi Government College.',
      quickLinks: 'Navigation',
      explore: 'Explore',
      directContact: 'Contact Office',
      rights: 'All rights reserved.',
    },
  },
};
