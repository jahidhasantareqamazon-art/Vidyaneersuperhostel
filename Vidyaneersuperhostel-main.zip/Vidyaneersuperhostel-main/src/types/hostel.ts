export type Language = 'bn' | 'en';

export type RoomCategory = 'single' | 'double' | 'multiple';
export type AvailabilityStatus = 'available' | 'limited' | 'full' | 'maintenance';
export type BookingStatusValue = 'pending' | 'approved' | 'rejected' | 'completed';
export type InquiryStatus = 'new' | 'read' | 'replied';
export type GalleryCategory = 'rooms' | 'building' | 'common' | 'facilities';
export type AdminRole = 'super_admin' | 'manager';

export interface AdminProfile {
  uid: string;
  email: string;
  displayName: string;
  phone?: string;
  role: AdminRole;
  designation?: string;
  updatedAt: string;
}

export interface Room {
  id: string;
  category: RoomCategory;
  titleBn: string;
  titleEn: string;
  descriptionBn: string;
  descriptionEn: string;
  capacity: number;
  availableSeats: number;
  monthlyRent: number | null;
  priceConfirmed: boolean;
  pricePlaceholderBn: string;
  pricePlaceholderEn: string;
  availabilityStatus: AvailabilityStatus;
  facilitiesBn: string[];
  facilitiesEn: string[];
  primaryImage: string;
  sortOrder: number;
  updatedAt: string;
}

export interface RoomImage {
  id: string;
  roomId: string;
  imageUrl: string;
  captionBn?: string;
  captionEn?: string;
  sortOrder: number;
  createdAt: string;
}

export interface BookingRecord {
  id: string;
  bookingCode: string;
  studentName: string;
  mobile: string;
  guardianMobile: string;
  institution: string;
  roomId: string;
  roomType: string;
  occupants: number;
  preferredDate: string;
  message?: string;
  status: BookingStatusValue;
  adminNote?: string;
  createdAt: string;
  updatedAt: string;
}

export interface PublicBookingStatus {
  bookingCode: string;
  roomType: string;
  preferredDate: string;
  status: BookingStatusValue;
  createdAt: string;
  updatedAt: string;
}

export interface InquiryRecord {
  id: string;
  senderName: string;
  phone: string;
  subject: string;
  message: string;
  status: InquiryStatus;
  createdAt: string;
}

export interface FacilityItem {
  id: string;
  key: string;
  titleBn: string;
  titleEn: string;
  descriptionBn: string;
  descriptionEn: string;
  isConfirmed: boolean;
  isActive: boolean;
  sortOrder: number;
}

export interface GalleryItem {
  id: string;
  category: GalleryCategory;
  titleBn: string;
  titleEn: string;
  imageUrl: string;
  sortOrder: number;
  createdAt: string;
}

export interface TestimonialItem {
  id: string;
  authorName: string;
  roleBn: string;
  roleEn: string;
  institution: string;
  quoteBn: string;
  quoteEn: string;
  isPublished: boolean;
  createdAt: string;
}

export interface WebsiteSettings {
  hostelName: string;
  hostelNameBn: string;
  addressBn: string;
  addressEn: string;
  phones: string[];
  whatsappNumbers: string[];
  heroHeadingBn: string;
  heroHeadingEn: string;
  heroSubheadingBn: string;
  heroSubheadingEn: string;
  aboutBn: string;
  aboutEn: string;
  seoTitle: string;
  seoDescription: string;
  seoKeywords: string;
  updatedAt: string;
}

export interface DashboardStats {
  totalRooms: number;
  totalCapacity: number;
  availableSeats: number;
  occupiedSeats: number;
  availableRooms: number;
  occupiedRooms: number;
  pendingBookings: number;
  approvedBookings: number;
  totalInquiries: number;
}
