import { useState } from 'react';
import { Link } from 'react-router-dom';
import {
  ArrowRight,
  BookOpen,
  CheckCircle2,
  Clock,
  Droplets,
  ExternalLink,
  MapPin,
  MessageSquareQuote,
  Shield,
  Sparkles,
  Utensils,
  Wifi,
  Zap,
} from 'lucide-react';
import { BookingSection } from '../components/BookingSection';
import { ContactSection } from '../components/ContactSection';
import { RoomCard } from '../components/RoomCard';
import { RoomDetailModal } from '../components/RoomDetailModal';
import { SafeImage } from '../components/SafeImage';
import { useApp } from '../contexts/AppContext';
import { MEDIA_ASSETS } from '../data/defaults';
import type { GalleryCategory, Room } from '../types/hostel';
import { getNarsingdiMapsSearchUrl } from '../utils/validation';

export function HomePage() {
  const {
    lang,
    setLang,
    t,
    settings,
    rooms,
    roomImages,
    facilities,
    gallery,
    testimonials,
  } = useApp();

  const [selectedRoomId, setSelectedRoomId] = useState<string | undefined>(undefined);
  const [modalRoom, setModalRoom] = useState<Room | null>(null);
  const [galleryFilter, setGalleryFilter] = useState<'all' | GalleryCategory>('all');
  const [lightboxImage, setLightboxImage] = useState<{ url: string; title: string } | null>(null);

  const totalSeatsAvailable = rooms.reduce((sum, r) => sum + Math.max(0, r.availableSeats), 0);

  const scrollToBookingWithRoom = (room: Room) => {
    setSelectedRoomId(room.id);
    const el = document.getElementById('booking');
    if (el) {
      el.scrollIntoView({ behavior: 'smooth' });
    }
  };

  const facilityIcon = (key: string) => {
    switch (key) {
      case 'clean_accommodation':
        return Sparkles;
      case 'study_environment':
        return BookOpen;
      case 'electricity':
        return Zap;
      case 'drinking_water':
        return Droplets;
      case 'security':
        return Shield;
      case 'wifi':
        return Wifi;
      case 'dining':
        return Utensils;
      default:
        return CheckCircle2;
    }
  };

  const filteredGallery =
    galleryFilter === 'all'
      ? gallery
      : gallery.filter((item) => item.category === galleryFilter);

  return (
    <div>
      {/* 1. Hero Section */}
      <section className="relative bg-[#0F2342] text-white overflow-hidden">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 pt-6 pb-16 lg:py-20">
          {/* Clean Language Utility Bar inside Hero */}
          <div className="flex flex-wrap items-center justify-between gap-4 pb-8 border-b border-white/10">
            <p className="text-xs sm:text-sm text-slate-300 flex items-center gap-2">
              <MapPin className="w-4 h-4 text-[#D99B26] shrink-0" aria-hidden="true" />
              <span>{t.hero.locationTag}</span>
            </p>
            <div className="inline-flex items-center gap-1 p-1 bg-white/10 rounded-lg">
              <button
                type="button"
                onClick={() => setLang('bn')}
                className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors ${
                  lang === 'bn' ? 'bg-[#D99B26] text-[#0F2342]' : 'text-slate-200 hover:text-white'
                }`}
              >
                বাংলা
              </button>
              <button
                type="button"
                onClick={() => setLang('en')}
                className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors ${
                  lang === 'en' ? 'bg-[#D99B26] text-[#0F2342]' : 'text-slate-200 hover:text-white'
                }`}
              >
                English
              </button>
            </div>
          </div>

          <div className="mt-10 grid grid-cols-1 lg:grid-cols-12 gap-10 items-stretch">
            <div className="lg:col-span-6 flex flex-col justify-center space-y-6">
              <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold leading-tight tracking-tight text-white [text-wrap:balance]">
                {lang === 'bn' ? settings.heroHeadingBn : settings.heroHeadingEn}
              </h1>
              <p className="text-base sm:text-lg text-slate-200 leading-relaxed max-w-xl">
                {lang === 'bn' ? settings.heroSubheadingBn : settings.heroSubheadingEn}
              </p>

              <div className="flex flex-wrap items-center gap-3.5 pt-2">
                <a
                  href="#booking"
                  className="inline-flex items-center justify-center gap-2 px-6 py-3.5 text-sm font-semibold text-[#0F2342] bg-[#D99B26] hover:bg-[#e5aa36] rounded-lg transition-colors duration-150 whitespace-nowrap"
                >
                  {t.hero.ctaBook}
                  <ArrowRight className="w-4 h-4" aria-hidden="true" />
                </a>
                <a
                  href="#contact"
                  className="inline-flex items-center justify-center px-6 py-3.5 text-sm font-semibold text-white border border-white/25 hover:bg-white/10 rounded-lg transition-colors duration-150 whitespace-nowrap"
                >
                  {t.hero.ctaContact}
                </a>
              </div>
            </div>

            <div className="lg:col-span-6">
              <div className="relative h-full min-h-[260px] sm:min-h-[340px] rounded-xl overflow-hidden border border-white/15">
                <SafeImage
                  src={MEDIA_ASSETS.heroHostelImg}
                  alt={lang === 'bn' ? 'বিদ্যা নীড় সুপার হোস্টেল ভবন' : 'Bidya Neer Super Hostel Building'}
                  loading="eager"
                  className="w-full h-full lg:h-full object-cover"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-[#0F2342]/60 via-transparent to-transparent pointer-events-none" />
              </div>
            </div>
          </div>

          {/* 4-column Highlights Strip directly below Hero split */}
          <div className="mt-12 grid grid-cols-2 lg:grid-cols-4 gap-4 pt-8 border-t border-white/10">
            <div className="p-4 rounded-lg bg-white/5 border border-white/10">
              <span className="text-xs text-slate-300 block">{t.hero.statsRoomsLabel}</span>
              <span className="text-2xl font-bold text-[#D99B26] tabular-nums mt-1 block">
                {rooms.length}
              </span>
            </div>
            <div className="p-4 rounded-lg bg-white/5 border border-white/10">
              <span className="text-xs text-slate-300 block">{t.hero.statsSeatsLabel}</span>
              <span className="text-2xl font-bold text-white tabular-nums mt-1 block">
                {totalSeatsAvailable}
              </span>
            </div>
            <div className="p-4 rounded-lg bg-white/5 border border-white/10">
              <span className="text-xs text-slate-300 block">{t.hero.statsLocationLabel}</span>
              <span className="text-lg font-bold text-white mt-1 block">
                {t.hero.statsLocationValue}
              </span>
            </div>
            <div className="p-4 rounded-lg bg-white/5 border border-white/10">
              <span className="text-xs text-slate-300 block">{t.hero.statsSupportLabel}</span>
              <span className="text-lg font-bold text-[#D99B26] font-mono-tabular mt-1 block">
                {settings.phones[0] || t.hero.statsSupportValue}
              </span>
            </div>
          </div>
        </div>
      </section>

      {/* 2. About Bidyanidhi Hostel */}
      <section id="about" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-12 items-stretch">
            <div className="lg:col-span-5">
              <div className="h-full min-h-[280px] rounded-xl overflow-hidden border border-slate-200">
                <SafeImage
                  src={MEDIA_ASSETS.readingHallImg}
                  alt={lang === 'bn' ? 'অধ্যয়ন কক্ষ' : 'Student Reading Room'}
                  className="w-full h-full object-cover"
                />
              </div>
            </div>

            <div className="lg:col-span-7 flex flex-col justify-center space-y-6">
              <div>
                <p className="text-xs font-semibold tracking-wider text-[#B67E16] mb-2">
                  {t.about.kicker}
                </p>
                <h2 className="text-3xl sm:text-4xl font-bold text-[#0F2342] [text-wrap:balance]">
                  {t.about.title}
                </h2>
              </div>

              <p className="text-base text-slate-700 leading-relaxed">
                {lang === 'bn' ? settings.aboutBn : settings.aboutEn}
              </p>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-6 pt-4 border-t border-slate-200">
                <div>
                  <h3 className="text-base font-bold text-[#0F2342] mb-1.5">
                    {t.about.locationAdvantageTitle}
                  </h3>
                  <p className="text-sm text-slate-600 leading-relaxed">
                    {t.about.locationAdvantageBody}
                  </p>
                </div>
                <div>
                  <h3 className="text-base font-bold text-[#0F2342] mb-1.5">
                    {t.about.studentFocusTitle}
                  </h3>
                  <p className="text-sm text-slate-600 leading-relaxed">
                    {t.about.studentFocusBody}
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* 3. Why Choose Us */}
      <section className="py-20 bg-[#F6F7FA] border-y border-slate-200/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl mb-12">
            <h2 className="text-3xl sm:text-4xl font-bold text-[#0F2342] [text-wrap:balance]">
              {t.about.whyTitle}
            </h2>
            <p className="mt-3 text-base text-slate-600 leading-relaxed">
              {t.about.whySubtitle}
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {t.about.reasons.map((reason, idx) => (
              <div
                key={reason.title}
                className="bg-white border border-slate-200 rounded-xl p-6 space-y-2.5"
              >
                <span className="text-xs font-mono-tabular font-semibold text-[#B67E16]">
                  0{idx + 1}.
                </span>
                <h3 className="text-lg font-bold text-[#0F2342]">{reason.title}</h3>
                <p className="text-sm text-slate-600 leading-relaxed">{reason.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* 4. Room Categories */}
      <section id="rooms" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col sm:flex-row sm:items-end justify-between gap-4 mb-12">
            <div className="max-w-2xl">
              <p className="text-xs font-semibold tracking-wider text-[#B67E16] mb-2">
                {t.rooms.kicker}
              </p>
              <h2 className="text-3xl sm:text-4xl font-bold text-[#0F2342] [text-wrap:balance]">
                {t.rooms.title}
              </h2>
              <p className="mt-3 text-base text-slate-600 leading-relaxed">
                {t.rooms.subtitle}
              </p>
            </div>
            <Link
              to="/rooms"
              className="inline-flex items-center gap-1.5 text-sm font-semibold text-[#0F2342] hover:text-[#B67E16] whitespace-nowrap"
            >
              {t.hero.ctaRooms}
              <ArrowRight className="w-4 h-4" aria-hidden="true" />
            </Link>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-7">
            {rooms.map((room) => (
              <RoomCard
                key={room.id}
                room={room}
                onBookRoom={scrollToBookingWithRoom}
                onViewDetails={setModalRoom}
              />
            ))}
          </div>
        </div>
      </section>

      {/* 5. Facilities Section */}
      <section id="facilities" className="py-20 bg-[#F6F7FA] border-y border-slate-200/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl mb-12">
            <p className="text-xs font-semibold tracking-wider text-[#B67E16] mb-2">
              {t.facilities.kicker}
            </p>
            <h2 className="text-3xl sm:text-4xl font-bold text-[#0F2342] [text-wrap:balance]">
              {t.facilities.title}
            </h2>
            <p className="mt-3 text-base text-slate-600 leading-relaxed">
              {t.facilities.subtitle}
            </p>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-5">
            {facilities
              .filter((f) => f.isActive)
              .map((fac) => {
                const Icon = facilityIcon(fac.key);
                return (
                  <div
                    key={fac.id}
                    className="bg-white border border-slate-200 rounded-xl p-5 flex flex-col justify-between space-y-4"
                  >
                    <div className="space-y-3">
                      <div className="w-10 h-10 rounded-lg bg-[#0F2342]/5 text-[#0F2342] flex items-center justify-center">
                        <Icon className="w-5 h-5" aria-hidden="true" />
                      </div>
                      <h3 className="text-base font-bold text-[#0F2342]">
                        {lang === 'bn' ? fac.titleBn : fac.titleEn}
                      </h3>
                      <p className="text-sm text-slate-600 leading-relaxed">
                        {lang === 'bn' ? fac.descriptionBn : fac.descriptionEn}
                      </p>
                    </div>
                    <div className="pt-3 border-t border-slate-100 text-xs font-semibold flex items-center gap-1.5">
                      {fac.isConfirmed ? (
                        <>
                          <CheckCircle2 className="w-3.5 h-3.5 text-emerald-700" aria-hidden="true" />
                          <span className="text-emerald-700">{t.facilities.confirmedLabel}</span>
                        </>
                      ) : (
                        <>
                          <Clock className="w-3.5 h-3.5 text-amber-700" aria-hidden="true" />
                          <span className="text-amber-700">{t.facilities.pendingConfirmLabel}</span>
                        </>
                      )}
                    </div>
                  </div>
                );
              })}
          </div>
        </div>
      </section>

      {/* 6. Photo Gallery */}
      <section id="gallery" className="py-20 bg-white">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex flex-col md:flex-row md:items-end justify-between gap-6 mb-10">
            <div>
              <p className="text-xs font-semibold tracking-wider text-[#B67E16] mb-2">
                {t.gallery.kicker}
              </p>
              <h2 className="text-3xl sm:text-4xl font-bold text-[#0F2342] [text-wrap:balance]">
                {t.gallery.title}
              </h2>
              <p className="mt-2 text-base text-slate-600">{t.gallery.subtitle}</p>
            </div>

            <div className="flex flex-wrap items-center gap-1 p-1 bg-slate-100 rounded-lg self-start">
              {(
                [
                  { id: 'all', label: t.gallery.all },
                  { id: 'rooms', label: t.gallery.rooms },
                  { id: 'building', label: t.gallery.building },
                  { id: 'common', label: t.gallery.common },
                  { id: 'facilities', label: t.gallery.facilities },
                ] as const
              ).map((tab) => (
                <button
                  key={tab.id}
                  type="button"
                  onClick={() => setGalleryFilter(tab.id)}
                  className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                    galleryFilter === tab.id
                      ? 'bg-white text-[#0F2342] shadow-sm'
                      : 'text-slate-600 hover:text-[#0F2342]'
                  }`}
                >
                  {tab.label}
                </button>
              ))}
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {filteredGallery.map((item) => {
              const label = lang === 'bn' ? item.titleBn : item.titleEn;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setLightboxImage({ url: item.imageUrl, title: label })}
                  className="group text-left bg-white border border-slate-200 rounded-xl overflow-hidden focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#D99B26]"
                >
                  <div className="aspect-[4/3] w-full overflow-hidden bg-slate-100">
                    <SafeImage
                      src={item.imageUrl}
                      alt={label}
                      className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.03]"
                    />
                  </div>
                  <div className="p-4">
                    <span className="text-xs text-slate-500 block mb-0.5">
                      {t.gallery[item.category]}
                    </span>
                    <h3 className="text-sm font-semibold text-[#0F2342]">{label}</h3>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {/* 7. Booking / Inquiry Section */}
      <BookingSection preselectedRoomId={selectedRoomId} />

      {/* 8. Testimonials (Admin-managed, never fabricated) */}
      <section className="py-20 bg-white border-t border-slate-200/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="max-w-2xl mb-10">
            <p className="text-xs font-semibold tracking-wider text-[#B67E16] mb-2">
              {t.testimonials.kicker}
            </p>
            <h2 className="text-3xl sm:text-4xl font-bold text-[#0F2342] [text-wrap:balance]">
              {t.testimonials.title}
            </h2>
          </div>

          {testimonials.length === 0 ? (
            <div className="bg-[#F6F7FA] border border-slate-200 rounded-xl p-8 max-w-2xl space-y-2">
              <div className="flex items-center gap-2.5 text-[#0F2342]">
                <MessageSquareQuote className="w-5 h-5 text-[#D99B26]" aria-hidden="true" />
                <h3 className="text-base font-bold">{t.testimonials.emptyTitle}</h3>
              </div>
              <p className="text-sm text-slate-600 leading-relaxed">{t.testimonials.emptyBody}</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {testimonials.map((item) => (
                <blockquote
                  key={item.id}
                  className="bg-[#F6F7FA] border border-slate-200 rounded-xl p-6 flex flex-col justify-between space-y-5"
                >
                  <p className="text-sm text-slate-700 leading-relaxed">
                    “{lang === 'bn' ? item.quoteBn : item.quoteEn}”
                  </p>
                  <footer className="pt-4 border-t border-slate-200/80">
                    <cite className="not-italic font-bold text-sm text-[#0F2342] block">
                      {item.authorName}
                    </cite>
                    <span className="text-xs text-slate-500">
                      {lang === 'bn' ? item.roleBn : item.roleEn} · {item.institution}
                    </span>
                  </footer>
                </blockquote>
              ))}
            </div>
          )}
        </div>
      </section>

      {/* 9. Location Section */}
      <section className="py-16 bg-[#F6F7FA] border-t border-slate-200/80">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="bg-white border border-slate-200 rounded-xl p-6 sm:p-10 grid grid-cols-1 lg:grid-cols-12 gap-8 items-center">
            <div className="lg:col-span-7 space-y-4">
              <p className="text-xs font-semibold tracking-wider text-[#B67E16]">
                {t.location.kicker}
              </p>
              <h2 className="text-2xl sm:text-3xl font-bold text-[#0F2342]">{t.location.title}</h2>
              <p className="text-base font-medium text-slate-800">
                {lang === 'bn' ? settings.addressBn : settings.addressEn}
              </p>
              <a
                href={getNarsingdiMapsSearchUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 px-5 py-2.5 text-sm font-semibold text-white bg-[#0F2342] hover:bg-[#193766] rounded-lg transition-colors"
              >
                <MapPin className="w-4 h-4 text-[#D99B26]" aria-hidden="true" />
                {t.location.openGoogleMaps}
                <ExternalLink className="w-4 h-4" aria-hidden="true" />
              </a>
            </div>

            <div className="lg:col-span-5 bg-[#F6F7FA] border border-slate-200 rounded-lg p-5 space-y-3">
              <h3 className="text-sm font-bold text-[#0F2342]">{t.location.nearbyLabel}</h3>
              <ul className="space-y-2 text-sm text-slate-700">
                {t.location.nearbyPlaces.map((place) => (
                  <li key={place} className="flex items-start gap-2">
                    <span className="text-[#D99B26] font-bold" aria-hidden="true">•</span>
                    <span>{place}</span>
                  </li>
                ))}
              </ul>
            </div>
          </div>
        </div>
      </section>

      {/* 10. Contact Section */}
      <ContactSection />

      {/* Room Detail Modal */}
      <RoomDetailModal
        room={modalRoom}
        images={roomImages}
        onClose={() => setModalRoom(null)}
        onBook={scrollToBookingWithRoom}
      />

      {/* Gallery Lightbox */}
      {lightboxImage && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={lightboxImage.title}
          className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setLightboxImage(null)}
        >
          <div
            className="max-w-3xl w-full bg-white rounded-xl overflow-hidden shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="aspect-[16/10] bg-slate-100">
              <SafeImage
                src={lightboxImage.url}
                alt={lightboxImage.title}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="px-6 py-4 flex items-center justify-between gap-4">
              <p className="text-sm font-semibold text-[#0F2342]">{lightboxImage.title}</p>
              <button
                type="button"
                onClick={() => setLightboxImage(null)}
                className="px-4 py-1.5 text-xs font-semibold text-white bg-[#0F2342] rounded-lg"
              >
                {lang === 'bn' ? 'বন্ধ করুন' : 'Close'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
