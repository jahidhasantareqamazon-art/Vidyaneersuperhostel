import { ContactSection } from '../components/ContactSection';
import { LanguageSwitchPill } from '../components/LanguageSwitchPill';
import { useApp } from '../contexts/AppContext';

export function ContactPage() {
  const { t, lang, settings } = useApp();

  return (
    <div className="bg-white min-h-[70vh]">
      <section className="bg-[#0F2342] text-white py-14">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row sm:items-end justify-between gap-6">
          <div className="space-y-3">
            <p className="text-xs font-semibold tracking-wider text-[#D99B26]">{t.contact.kicker}</p>
            <h1 className="text-3xl sm:text-4xl font-bold [text-wrap:balance]">{t.contact.title}</h1>
            <p className="text-base text-slate-300 max-w-2xl">
              {lang === 'bn' ? settings.addressBn : settings.addressEn}
            </p>
          </div>
          <LanguageSwitchPill />
        </div>
      </section>

      <ContactSection hideHeader />
    </div>
  );
}
