import {
  BookOpen,
  CheckCircle2,
  Clock,
  Droplets,
  Shield,
  Sparkles,
  Utensils,
  Wifi,
  Zap,
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { LanguageSwitchPill } from '../components/LanguageSwitchPill';
import { useApp } from '../contexts/AppContext';

export function FacilitiesPage() {
  const { lang, t, facilities } = useApp();

  const iconFor = (key: string) => {
    switch (key) {
      case 'clean_accommodation':
        return Sparkles;
      case 'study_environment':
        return BookOpen;
      case 'electricity':
        return Zap;
      case 'drinking_water':
        return Droplets;
      case 'security':
        return Shield;
      case 'wifi':
        return Wifi;
      case 'dining':
        return Utensils;
      default:
        return CheckCircle2;
    }
  };

  return (
    <div className="bg-[#F6F7FA] min-h-[70vh]">
      <section className="bg-[#0F2342] text-white py-14">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row sm:items-end justify-between gap-6">
          <div className="space-y-3">
            <p className="text-xs font-semibold tracking-wider text-[#D99B26]">{t.facilities.kicker}</p>
            <h1 className="text-3xl sm:text-4xl font-bold [text-wrap:balance]">{t.facilities.title}</h1>
            <p className="text-base text-slate-300 max-w-2xl">{t.facilities.subtitle}</p>
          </div>
          <LanguageSwitchPill />
        </div>
      </section>

      <section className="py-14">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6">
            {facilities
              .filter((f) => f.isActive)
              .map((fac) => {
                const Icon = iconFor(fac.key);
                return (
                  <div
                    key={fac.id}
                    className="bg-white border border-slate-200 rounded-xl p-6 flex flex-col justify-between space-y-4"
                  >
                    <div className="space-y-3">
                      <div className="w-11 h-11 rounded-lg bg-[#0F2342]/5 text-[#0F2342] flex items-center justify-center">
                        <Icon className="w-5 h-5" aria-hidden="true" />
                      </div>
                      <h2 className="text-lg font-bold text-[#0F2342]">
                        {lang === 'bn' ? fac.titleBn : fac.titleEn}
                      </h2>
                      <p className="text-sm text-slate-600 leading-relaxed">
                        {lang === 'bn' ? fac.descriptionBn : fac.descriptionEn}
                      </p>
                    </div>
                    <div className="pt-3 border-t border-slate-100 text-xs font-semibold flex items-center gap-1.5">
                      {fac.isConfirmed ? (
                        <>
                          <CheckCircle2 className="w-4 h-4 text-emerald-700" aria-hidden="true" />
                          <span className="text-emerald-700">{t.facilities.confirmedLabel}</span>
                        </>
                      ) : (
                        <>
                          <Clock className="w-4 h-4 text-amber-700" aria-hidden="true" />
                          <span className="text-amber-700">{t.facilities.pendingConfirmLabel}</span>
                        </>
                      )}
                    </div>
                  </div>
                );
              })}
          </div>

          <div className="mt-12 bg-white border border-slate-200 rounded-xl p-6 sm:p-8 flex flex-col sm:flex-row sm:items-center justify-between gap-6">
            <div className="space-y-1">
              <h3 className="text-lg font-bold text-[#0F2342]">
                {lang === 'bn'
                  ? 'হোস্টেল সুবিধা ও ফি সম্পর্কে বিস্তারিত জানতে চান?'
                  : 'Have questions about specific hostel facilities?'}
              </h3>
              <p className="text-sm text-slate-600">
                {lang === 'bn'
                  ? 'আমাদের সাথে সরাসরি ফোনে অথবা বুকিং আবেদনের মাধ্যমে যোগাযোগ করুন।'
                  : 'Reach out directly by phone or submit a booking inquiry.'}
              </p>
            </div>
            <div className="flex items-center gap-3 shrink-0">
              <Link
                to="/booking"
                className="px-5 py-2.5 text-sm font-semibold text-white bg-[#0F2342] rounded-lg hover:bg-[#193766]"
              >
                {t.nav.bookRoom}
              </Link>
              <Link
                to="/contact"
                className="px-5 py-2.5 text-sm font-semibold text-[#0F2342] border border-slate-300 rounded-lg hover:bg-slate-50"
              >
                {t.nav.contact}
              </Link>
            </div>
          </div>
        </div>
      </section>
    </div>
  );
}
