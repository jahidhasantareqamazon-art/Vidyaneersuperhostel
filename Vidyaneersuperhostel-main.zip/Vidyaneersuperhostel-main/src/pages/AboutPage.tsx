import { Link } from 'react-router-dom';
import { ArrowRight, ExternalLink, MapPin } from 'lucide-react';
import { LanguageSwitchPill } from '../components/LanguageSwitchPill';
import { SafeImage } from '../components/SafeImage';
import { useApp } from '../contexts/AppContext';
import { MEDIA_ASSETS } from '../data/defaults';
import { getNarsingdiMapsSearchUrl } from '../utils/validation';

export function AboutPage() {
  const { lang, t, settings } = useApp();

  return (
    <div className="bg-white">
      <section className="bg-[#0F2342] text-white py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row sm:items-end justify-between gap-6">
          <div className="space-y-4">
            <p className="text-xs font-semibold tracking-wider text-[#D99B26]">{t.about.kicker}</p>
            <h1 className="text-3xl sm:text-4xl font-bold [text-wrap:balance] max-w-3xl">
              {t.about.title}
            </h1>
            <p className="text-base text-slate-300 max-w-2xl leading-relaxed">
              {lang === 'bn' ? settings.addressBn : settings.addressEn}
            </p>
          </div>
          <LanguageSwitchPill />
        </div>
      </section>

      <section className="py-16">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 grid grid-cols-1 lg:grid-cols-12 gap-12 items-stretch">
          <div className="lg:col-span-6 space-y-6">
            <p className="text-base text-slate-700 leading-relaxed">
              {lang === 'bn' ? settings.aboutBn : settings.aboutEn}
            </p>
            <div className="p-6 rounded-xl bg-[#F6F7FA] border border-slate-200 space-y-3">
              <h2 className="text-lg font-bold text-[#0F2342]">{t.about.locationAdvantageTitle}</h2>
              <p className="text-sm text-slate-600 leading-relaxed">
                {t.about.locationAdvantageBody}
              </p>
              <a
                href={getNarsingdiMapsSearchUrl()}
                target="_blank"
                rel="noopener noreferrer"
                className="inline-flex items-center gap-2 text-sm font-semibold text-[#0F2342] hover:text-[#B67E16]"
              >
                <MapPin className="w-4 h-4 text-[#D99B26]" aria-hidden="true" />
                {t.location.openGoogleMaps}
                <ExternalLink className="w-3.5 h-3.5" aria-hidden="true" />
              </a>
            </div>
            <div className="p-6 rounded-xl bg-[#F6F7FA] border border-slate-200 space-y-2">
              <h2 className="text-lg font-bold text-[#0F2342]">{t.about.studentFocusTitle}</h2>
              <p className="text-sm text-slate-600 leading-relaxed">
                {t.about.studentFocusBody}
              </p>
            </div>
            <div className="pt-2">
              <Link
                to="/booking"
                className="inline-flex items-center gap-2 px-6 py-3 text-sm font-semibold text-white bg-[#0F2342] hover:bg-[#193766] rounded-lg transition-colors"
              >
                {t.nav.bookRoom}
                <ArrowRight className="w-4 h-4" aria-hidden="true" />
              </Link>
            </div>
          </div>

          <div className="lg:col-span-6 grid grid-cols-1 gap-6">
            <div className="rounded-xl overflow-hidden border border-slate-200 aspect-[16/10]">
              <SafeImage
                src={MEDIA_ASSETS.heroHostelImg}
                alt={lang === 'bn' ? 'বিদ্যা নীড় সুপার হোস্টেল ভবন' : 'Bidya Neer Super Hostel Building'}
                className="w-full h-full object-cover"
              />
            </div>
            <div className="rounded-xl overflow-hidden border border-slate-200 aspect-[16/10]">
              <SafeImage
                src={MEDIA_ASSETS.readingHallImg}
                alt={lang === 'bn' ? 'অধ্যয়ন কক্ষ' : 'Reading Hall'}
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      <section className="py-16 bg-[#F6F7FA] border-t border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <h2 className="text-2xl sm:text-3xl font-bold text-[#0F2342] mb-8">{t.about.whyTitle}</h2>
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {t.about.reasons.map((reason, idx) => (
              <div key={reason.title} className="bg-white border border-slate-200 rounded-xl p-6 space-y-2">
                <span className="text-xs font-mono-tabular font-semibold text-[#B67E16]">0{idx + 1}.</span>
                <h3 className="text-base font-bold text-[#0F2342]">{reason.title}</h3>
                <p className="text-sm text-slate-600 leading-relaxed">{reason.body}</p>
              </div>
            ))}
          </div>
        </div>
      </section>
    </div>
  );
}
