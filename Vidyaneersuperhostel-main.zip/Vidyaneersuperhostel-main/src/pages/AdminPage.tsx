import { useCallback, useEffect, useState } from 'react';
import {
  BedDouble,
  CalendarCheck,
  LayoutDashboard,
  Lock,
  LogOut,
  Settings,
  Sparkles,
} from 'lucide-react';
import { AdminBookingsTab } from '../components/admin/AdminBookingsTab';
import { AdminContentAssetsTab } from '../components/admin/AdminContentAssetsTab';
import { AdminRoomsTab } from '../components/admin/AdminRoomsTab';
import { AdminSettingsTab } from '../components/admin/AdminSettingsTab';
import { useApp } from '../contexts/AppContext';
import { fetchAdminDashboardData } from '../services/hostelService';
import type {
  AdminProfile,
  BookingRecord,
  InquiryRecord,
  TestimonialItem,
} from '../types/hostel';
import { computeDashboardStats } from '../utils/validation';

type AdminTab = 'overview' | 'bookings' | 'rooms' | 'assets' | 'settings';

export function AdminPage() {
  const { user, authReady, isAdmin, adminChecking, rooms, signInWithGoogle, logout } = useApp();

  const [tab, setTab] = useState<AdminTab>('overview');
  const [loading, setLoading] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  const [bookings, setBookings] = useState<BookingRecord[]>([]);
  const [inquiries, setInquiries] = useState<InquiryRecord[]>([]);
  const [testimonials, setTestimonials] = useState<TestimonialItem[]>([]);
  const [adminProfile, setAdminProfile] = useState<AdminProfile | null>(null);

  const loadAdminData = useCallback(async () => {
    if (!isAdmin) return;
    setLoading(true);
    setErrorMsg(null);
    try {
      const res = await fetchAdminDashboardData();
      setBookings(res.bookings);
      setInquiries(res.inquiries);
      setTestimonials(res.testimonials);
      setAdminProfile(res.adminProfile);
    } catch {
      setErrorMsg('Unable to load admin records. Check Firestore permissions and try again.');
    } finally {
      setLoading(false);
    }
  }, [isAdmin]);

  useEffect(() => {
    if (isAdmin) {
      loadAdminData();
    }
  }, [isAdmin, loadAdminData]);

  if (!authReady || adminChecking) {
    return (
      <div className="min-h-[70vh] flex items-center justify-center bg-[#F6F7FA]">
        <p className="text-sm font-medium text-slate-600">Verifying administrator session...</p>
      </div>
    );
  }

  if (!user) {
    return (
      <div className="min-h-[75vh] bg-[#F6F7FA] flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-white border border-slate-200 rounded-xl p-8 space-y-6 text-center">
          <div className="w-12 h-12 mx-auto rounded-lg bg-[#0F2342]/5 text-[#0F2342] flex items-center justify-center">
            <Lock className="w-6 h-6" />
          </div>
          <div className="space-y-2">
            <h1 className="text-2xl font-bold text-[#0F2342]">Bidya Neer Super Hostel Admin</h1>
            <p className="text-sm text-slate-600 leading-relaxed">
              Sign in with your authorized administrator Google account to manage bookings, room
              availability, monthly rent, facilities, gallery, and site settings.
            </p>
          </div>
          <button
            type="button"
            onClick={() => signInWithGoogle()}
            className="w-full inline-flex items-center justify-center gap-2 px-5 py-3 text-sm font-semibold text-white bg-[#0F2342] hover:bg-[#193766] rounded-lg transition-colors"
          >
            Sign in with Google
          </button>
        </div>
      </div>
    );
  }

  if (!isAdmin) {
    return (
      <div className="min-h-[75vh] bg-[#F6F7FA] flex items-center justify-center p-4">
        <div className="max-w-md w-full bg-white border border-slate-200 rounded-xl p-8 space-y-5 text-center">
          <h1 className="text-xl font-bold text-rose-800">Access Restricted</h1>
          <p className="text-sm text-slate-600">
            The signed-in account ({user.email}) is not registered as an administrator for
            Bidya Neer Super Hostel.
          </p>
          <button
            type="button"
            onClick={() => logout()}
            className="inline-flex items-center justify-center gap-2 px-5 py-2.5 text-sm font-semibold text-[#0F2342] border border-slate-300 rounded-lg hover:bg-slate-50"
          >
            <LogOut className="w-4 h-4" />
            Sign Out
          </button>
        </div>
      </div>
    );
  }

  const stats = computeDashboardStats(rooms, bookings, inquiries);

  const navItems: { id: AdminTab; label: string; Icon: typeof LayoutDashboard }[] = [
    { id: 'overview', label: 'Overview', Icon: LayoutDashboard },
    { id: 'bookings', label: `Bookings (${stats.pendingBookings})`, Icon: CalendarCheck },
    { id: 'rooms', label: 'Rooms & Pricing', Icon: BedDouble },
    { id: 'assets', label: 'Facilities & Media', Icon: Sparkles },
    { id: 'settings', label: 'Inquiries & Settings', Icon: Settings },
  ];

  return (
    <div className="min-h-[85vh] bg-[#F6F7FA] flex flex-col lg:flex-row">
      {/* Sidebar */}
      <aside className="w-full lg:w-64 bg-white border-b lg:border-b-0 lg:border-r border-slate-200 shrink-0">
        <div className="p-5 border-b border-slate-200">
          <p className="text-xs font-semibold text-[#B67E16]">Admin Console</p>
          <p className="text-sm font-bold text-[#0F2342] truncate mt-0.5">
            {adminProfile?.displayName || user.displayName || user.email}
          </p>
        </div>
        <nav aria-label="Admin Navigation" className="p-3 flex lg:flex-col gap-1 overflow-x-auto">
          {navItems.map(({ id, label, Icon }) => (
            <button
              key={id}
              type="button"
              onClick={() => setTab(id)}
              className={`flex items-center gap-2.5 px-3.5 py-2.5 rounded-lg text-sm font-medium whitespace-nowrap transition-colors ${
                tab === id
                  ? 'bg-[#0F2342] text-white'
                  : 'text-slate-700 hover:bg-slate-100'
              }`}
            >
              <Icon className="w-4 h-4 shrink-0" />
              <span>{label}</span>
            </button>
          ))}
        </nav>
        <div className="p-4 border-t border-slate-200 hidden lg:block">
          <button
            type="button"
            onClick={() => logout()}
            className="w-full inline-flex items-center justify-center gap-2 px-3.5 py-2 text-xs font-semibold text-slate-700 border border-slate-300 rounded-lg hover:bg-slate-50"
          >
            <LogOut className="w-3.5 h-3.5" />
            Sign Out
          </button>
        </div>
      </aside>

      {/* Main Content */}
      <main className="flex-1 p-4 sm:p-8 max-w-6xl">
        {errorMsg && (
          <div className="mb-6 p-4 rounded-lg bg-rose-50 border border-rose-200 text-sm text-rose-900">
            {errorMsg}
          </div>
        )}

        {loading && tab === 'overview' ? (
          <div className="grid grid-cols-2 lg:grid-cols-4 gap-4">
            {[1, 2, 3, 4].map((n) => (
              <div key={n} className="h-24 bg-white border border-slate-200 rounded-xl animate-pulse" />
            ))}
          </div>
        ) : (
          <>
            {tab === 'overview' && (
              <div className="space-y-8">
                <div>
                  <h1 className="text-2xl font-bold text-[#0F2342]">Hostel Dashboard Overview</h1>
                  <p className="text-sm text-slate-600 mt-1">
                    Live occupancy, booking pipeline, and contact inquiry summary.
                  </p>
                </div>

                <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
                  {[
                    { label: 'Total Rooms', value: stats.totalRooms },
                    { label: 'Available Rooms', value: stats.availableRooms },
                    { label: 'Occupied Rooms', value: stats.occupiedRooms },
                    { label: 'Pending Bookings', value: stats.pendingBookings },
                    { label: 'Approved Bookings', value: stats.approvedBookings },
                    { label: 'Total Inquiries', value: stats.totalInquiries },
                  ].map((metric) => (
                    <div
                      key={metric.label}
                      className="bg-white border border-slate-200 rounded-xl p-4 space-y-1"
                    >
                      <span className="text-xs font-medium text-slate-500 block">
                        {metric.label}
                      </span>
                      <span className="text-2xl font-bold text-[#0F2342] font-mono-tabular block">
                        {metric.value}
                      </span>
                    </div>
                  ))}
                </div>

                <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
                  <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
                    <div className="flex items-center justify-between">
                      <h2 className="text-base font-bold text-[#0F2342]">Pending Booking Queue</h2>
                      <button
                        type="button"
                        onClick={() => setTab('bookings')}
                        className="text-xs font-semibold text-[#B67E16] hover:underline"
                      >
                        Manage All
                      </button>
                    </div>
                    {bookings.filter((b) => b.status === 'pending').length === 0 ? (
                      <p className="text-sm text-slate-500">No pending bookings awaiting review.</p>
                    ) : (
                      <ul className="divide-y divide-slate-100 text-sm">
                        {bookings
                          .filter((b) => b.status === 'pending')
                          .slice(0, 5)
                          .map((b) => (
                            <li key={b.id} className="py-2.5 flex items-center justify-between gap-2">
                              <div>
                                <span className="font-semibold text-[#0F2342] block">
                                  {b.studentName}
                                </span>
                                <span className="text-xs text-slate-500">
                                  {b.roomType} · {b.mobile}
                                </span>
                              </div>
                              <span className="font-mono-tabular text-xs font-semibold text-amber-700">
                                {b.bookingCode}
                              </span>
                            </li>
                          ))}
                      </ul>
                    )}
                  </div>

                  <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
                    <div className="flex items-center justify-between">
                      <h2 className="text-base font-bold text-[#0F2342]">Recent Inquiries</h2>
                      <button
                        type="button"
                        onClick={() => setTab('settings')}
                        className="text-xs font-semibold text-[#B67E16] hover:underline"
                      >
                        Open Inbox
                      </button>
                    </div>
                    {inquiries.length === 0 ? (
                      <p className="text-sm text-slate-500">No contact inquiries received yet.</p>
                    ) : (
                      <ul className="divide-y divide-slate-100 text-sm">
                        {inquiries.slice(0, 5).map((inq) => (
                          <li key={inq.id} className="py-2.5 flex items-center justify-between gap-2">
                            <div>
                              <span className="font-semibold text-[#0F2342] block">
                                {inq.senderName}
                              </span>
                              <span className="text-xs text-slate-500">{inq.subject}</span>
                            </div>
                            <span className="font-mono-tabular text-xs text-slate-600">
                              {inq.phone}
                            </span>
                          </li>
                        ))}
                      </ul>
                    )}
                  </div>
                </div>
              </div>
            )}

            {tab === 'bookings' && (
              <AdminBookingsTab bookings={bookings} onRefresh={loadAdminData} />
            )}

            {tab === 'rooms' && <AdminRoomsTab />}

            {tab === 'assets' && (
              <AdminContentAssetsTab
                allTestimonials={testimonials}
                onRefreshAdmin={loadAdminData}
              />
            )}

            {tab === 'settings' && (
              <AdminSettingsTab
                inquiries={inquiries}
                bookings={bookings}
                adminProfile={adminProfile}
                onRefreshAdmin={loadAdminData}
              />
            )}
          </>
        )}
      </main>
    </div>
  );
}
