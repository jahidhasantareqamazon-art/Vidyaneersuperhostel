import { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { LanguageSwitchPill } from '../components/LanguageSwitchPill';
import { RoomCard } from '../components/RoomCard';
import { RoomDetailModal } from '../components/RoomDetailModal';
import { useApp } from '../contexts/AppContext';
import type { Room, RoomCategory } from '../types/hostel';

export function RoomsPage() {
  const { t, rooms, roomImages } = useApp();
  const navigate = useNavigate();
  const [filter, setFilter] = useState<'all' | RoomCategory>('all');
  const [modalRoom, setModalRoom] = useState<Room | null>(null);

  const filtered = filter === 'all' ? rooms : rooms.filter((r) => r.category === filter);

  const handleBook = (room: Room) => {
    navigate(`/booking?room=${encodeURIComponent(room.id)}`);
  };

  return (
    <div className="bg-[#F6F7FA] min-h-[70vh]">
      <section className="bg-[#0F2342] text-white py-14">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row sm:items-end justify-between gap-6">
          <div className="space-y-3">
            <p className="text-xs font-semibold tracking-wider text-[#D99B26]">{t.rooms.kicker}</p>
            <h1 className="text-3xl sm:text-4xl font-bold [text-wrap:balance]">{t.rooms.title}</h1>
            <p className="text-base text-slate-300 max-w-2xl">{t.rooms.subtitle}</p>
          </div>
          <LanguageSwitchPill />
        </div>
      </section>

      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8 inline-flex flex-wrap items-center gap-1 p-1 bg-white border border-slate-200 rounded-lg">
            {(
              [
                { id: 'all', label: t.rooms.categoryAll },
                { id: 'single', label: t.rooms.categorySingle },
                { id: 'double', label: t.rooms.categoryDouble },
                { id: 'multiple', label: t.rooms.categoryMultiple },
              ] as const
            ).map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setFilter(tab.id)}
                className={`px-3.5 py-2 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                  filter === tab.id
                    ? 'bg-[#0F2342] text-white'
                    : 'text-slate-600 hover:text-[#0F2342]'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-7">
            {filtered.map((room) => (
              <RoomCard
                key={room.id}
                room={room}
                onBookRoom={handleBook}
                onViewDetails={setModalRoom}
              />
            ))}
          </div>
        </div>
      </section>

      <RoomDetailModal
        room={modalRoom}
        images={roomImages}
        onClose={() => setModalRoom(null)}
        onBook={handleBook}
      />
    </div>
  );
}
