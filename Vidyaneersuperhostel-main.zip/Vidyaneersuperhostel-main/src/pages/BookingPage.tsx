import { useSearchParams } from 'react-router-dom';
import { BookingSection } from '../components/BookingSection';
import { LanguageSwitchPill } from '../components/LanguageSwitchPill';
import { useApp } from '../contexts/AppContext';

export function BookingPage() {
  const { t } = useApp();
  const [searchParams] = useSearchParams();
  const preselectedRoom = searchParams.get('room') || undefined;

  return (
    <div className="bg-[#F6F7FA] min-h-[70vh]">
      <section className="bg-[#0F2342] text-white py-14">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row sm:items-end justify-between gap-6">
          <div className="space-y-3">
            <p className="text-xs font-semibold tracking-wider text-[#D99B26]">{t.booking.kicker}</p>
            <h1 className="text-3xl sm:text-4xl font-bold [text-wrap:balance]">{t.booking.title}</h1>
            <p className="text-base text-slate-300 max-w-2xl">{t.booking.subtitle}</p>
          </div>
          <LanguageSwitchPill />
        </div>
      </section>

      <BookingSection preselectedRoomId={preselectedRoom} hideHeader />
    </div>
  );
}
