import { useState } from 'react';
import { LanguageSwitchPill } from '../components/LanguageSwitchPill';
import { SafeImage } from '../components/SafeImage';
import { useApp } from '../contexts/AppContext';
import type { GalleryCategory } from '../types/hostel';

export function GalleryPage() {
  const { lang, t, gallery } = useApp();
  const [filter, setFilter] = useState<'all' | GalleryCategory>('all');
  const [lightbox, setLightbox] = useState<{ url: string; title: string } | null>(null);

  const items = filter === 'all' ? gallery : gallery.filter((g) => g.category === filter);

  return (
    <div className="bg-[#F6F7FA] min-h-[70vh]">
      <section className="bg-[#0F2342] text-white py-14">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row sm:items-end justify-between gap-6">
          <div className="space-y-3">
            <p className="text-xs font-semibold tracking-wider text-[#D99B26]">{t.gallery.kicker}</p>
            <h1 className="text-3xl sm:text-4xl font-bold [text-wrap:balance]">{t.gallery.title}</h1>
            <p className="text-base text-slate-300 max-w-2xl">{t.gallery.subtitle}</p>
          </div>
          <LanguageSwitchPill />
        </div>
      </section>

      <section className="py-12">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="mb-8 inline-flex flex-wrap items-center gap-1 p-1 bg-white border border-slate-200 rounded-lg">
            {(
              [
                { id: 'all', label: t.gallery.all },
                { id: 'rooms', label: t.gallery.rooms },
                { id: 'building', label: t.gallery.building },
                { id: 'common', label: t.gallery.common },
                { id: 'facilities', label: t.gallery.facilities },
              ] as const
            ).map((tab) => (
              <button
                key={tab.id}
                type="button"
                onClick={() => setFilter(tab.id)}
                className={`px-3.5 py-2 text-xs font-semibold rounded-md transition-colors whitespace-nowrap ${
                  filter === tab.id
                    ? 'bg-[#0F2342] text-white'
                    : 'text-slate-600 hover:text-[#0F2342]'
                }`}
              >
                {tab.label}
              </button>
            ))}
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {items.map((item) => {
              const title = lang === 'bn' ? item.titleBn : item.titleEn;
              return (
                <button
                  key={item.id}
                  type="button"
                  onClick={() => setLightbox({ url: item.imageUrl, title })}
                  className="group text-left bg-white border border-slate-200 rounded-xl overflow-hidden"
                >
                  <div className="aspect-[4/3] bg-slate-100 overflow-hidden">
                    <SafeImage
                      src={item.imageUrl}
                      alt={title}
                      className="w-full h-full object-cover transition-transform duration-300 group-hover:scale-[1.03]"
                    />
                  </div>
                  <div className="p-4">
                    <span className="text-xs text-slate-500 block mb-0.5">
                      {t.gallery[item.category]}
                    </span>
                    <h2 className="text-sm font-semibold text-[#0F2342]">{title}</h2>
                  </div>
                </button>
              );
            })}
          </div>
        </div>
      </section>

      {lightbox && (
        <div
          role="dialog"
          aria-modal="true"
          aria-label={lightbox.title}
          className="fixed inset-0 z-50 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center p-4"
          onClick={() => setLightbox(null)}
        >
          <div
            className="max-w-3xl w-full bg-white rounded-xl overflow-hidden shadow-2xl"
            onClick={(e) => e.stopPropagation()}
          >
            <div className="aspect-[16/10] bg-slate-100">
              <SafeImage src={lightbox.url} alt={lightbox.title} className="w-full h-full object-cover" />
            </div>
            <div className="px-6 py-4 flex items-center justify-between gap-4">
              <p className="text-sm font-semibold text-[#0F2342]">{lightbox.title}</p>
              <button
                type="button"
                onClick={() => setLightbox(null)}
                className="px-4 py-1.5 text-xs font-semibold text-white bg-[#0F2342] rounded-lg"
              >
                {lang === 'bn' ? 'বন্ধ করুন' : 'Close'}
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
