import {
  collection,
  deleteDoc,
  doc,
  getDoc,
  getDocs,
  orderBy,
  query,
  serverTimestamp,
  setDoc,
  Timestamp,
  updateDoc,
  where,
  writeBatch,
} from 'firebase/firestore';
import {
  DEFAULT_FACILITIES,
  DEFAULT_GALLERY,
  DEFAULT_ROOM_IMAGES,
  DEFAULT_ROOMS,
  DEFAULT_SETTINGS,
} from '../data/defaults';
import { auth, BOOTSTRAPPED_ADMIN_EMAIL, db, handleFirestoreError, OperationType } from '../lib/firebase';
import type {
  AdminProfile,
  BookingRecord,
  BookingStatusValue,
  FacilityItem,
  GalleryItem,
  InquiryRecord,
  InquiryStatus,
  PublicBookingStatus,
  Room,
  RoomImage,
  TestimonialItem,
  WebsiteSettings,
} from '../types/hostel';
import {
  createSubmissionSignature,
  generateBookingCode,
  type BookingFormInput,
  type InquiryFormInput,
} from '../utils/validation';

function tsToIso(val: unknown): string {
  if (val instanceof Timestamp) {
    return val.toDate().toISOString();
  }
  if (typeof val === 'string') {
    return val;
  }
  return new Date().toISOString();
}

function makeDocId(prefix: string): string {
  const rand = Math.random().toString(36).slice(2, 10);
  return `${prefix}-${Date.now()}-${rand}`;
}

export async function checkIsUserAdmin(uid: string, email: string | null | undefined, emailVerified: boolean): Promise<boolean> {
  if (!emailVerified) return false;
  if (email === BOOTSTRAPPED_ADMIN_EMAIL) return true;
  try {
    const snap = await getDoc(doc(db, 'admins', uid));
    return snap.exists();
  } catch {
    return false;
  }
}

export async function fetchPublicWebsiteData(): Promise<{
  settings: WebsiteSettings;
  rooms: Room[];
  roomImages: RoomImage[];
  facilities: FacilityItem[];
  gallery: GalleryItem[];
  testimonials: TestimonialItem[];
  seededInFirestore: boolean;
}> {
  let settings = DEFAULT_SETTINGS;
  let rooms = DEFAULT_ROOMS;
  let roomImages = DEFAULT_ROOM_IMAGES;
  let facilities = DEFAULT_FACILITIES;
  let gallery = DEFAULT_GALLERY;
  let testimonials: TestimonialItem[] = [];
  let seededInFirestore = false;

  try {
    const [settingsSnap, roomsSnap, roomImgSnap, facSnap, galSnap, testSnap] = await Promise.all([
      getDoc(doc(db, 'website_settings', 'main')),
      getDocs(query(collection(db, 'rooms'), orderBy('sortOrder', 'asc'))),
      getDocs(query(collection(db, 'room_images'), orderBy('sortOrder', 'asc'))),
      getDocs(query(collection(db, 'facilities'), orderBy('sortOrder', 'asc'))),
      getDocs(query(collection(db, 'gallery'), orderBy('sortOrder', 'asc'))),
      getDocs(query(collection(db, 'testimonials'), where('isPublished', '==', true))),
    ]);

    if (settingsSnap.exists()) {
      const d = settingsSnap.data();
      const loadedSettings: WebsiteSettings = {
        ...(d as WebsiteSettings),
        updatedAt: tsToIso(d.updatedAt),
      };
      if (loadedSettings.hostelNameBn === 'বিদ্যানিধি হোস্টেল' || loadedSettings.hostelName === 'Bidyanidhi Hostel') {
        loadedSettings.hostelName = DEFAULT_SETTINGS.hostelName;
        loadedSettings.hostelNameBn = DEFAULT_SETTINGS.hostelNameBn;
        loadedSettings.aboutBn = DEFAULT_SETTINGS.aboutBn;
        loadedSettings.aboutEn = DEFAULT_SETTINGS.aboutEn;
        loadedSettings.seoTitle = DEFAULT_SETTINGS.seoTitle;
        loadedSettings.seoDescription = DEFAULT_SETTINGS.seoDescription;
        loadedSettings.seoKeywords = DEFAULT_SETTINGS.seoKeywords;
      }
      if (loadedSettings.phones?.[0] === '01783807171' || loadedSettings.whatsappNumbers?.[0] === '01783807171') {
        loadedSettings.phones = DEFAULT_SETTINGS.phones;
        loadedSettings.whatsappNumbers = DEFAULT_SETTINGS.whatsappNumbers;
      }
      settings = loadedSettings;
      seededInFirestore = true;
    }

    if (!roomsSnap.empty) {
      rooms = roomsSnap.docs.map((docSnap) => {
        const d = docSnap.data();
        return {
          ...(d as Room),
          id: docSnap.id,
          updatedAt: tsToIso(d.updatedAt),
        };
      });
      seededInFirestore = true;
    }

    if (!roomImgSnap.empty) {
      roomImages = roomImgSnap.docs.map((docSnap) => {
        const d = docSnap.data();
        return {
          ...(d as RoomImage),
          id: docSnap.id,
          createdAt: tsToIso(d.createdAt),
        };
      });
    }

    if (!facSnap.empty) {
      facilities = facSnap.docs.map((docSnap) => ({
        ...(docSnap.data() as FacilityItem),
        id: docSnap.id,
      }));
    }

    if (!galSnap.empty) {
      gallery = galSnap.docs.map((docSnap) => {
        const d = docSnap.data();
        return {
          ...(d as GalleryItem),
          id: docSnap.id,
          createdAt: tsToIso(d.createdAt),
        };
      });
    }

    if (!testSnap.empty) {
      testimonials = testSnap.docs.map((docSnap) => {
        const d = docSnap.data();
        return {
          ...(d as TestimonialItem),
          id: docSnap.id,
          createdAt: tsToIso(d.createdAt),
        };
      });
    }
  } catch (err) {
    console.warn('Using verified default catalog while Firestore initializes:', err);
  }

  return {
    settings,
    rooms,
    roomImages,
    facilities,
    gallery,
    testimonials,
    seededInFirestore,
  };
}

const recentSubmissions = new Map<string, number>();

export async function submitBooking(
  input: BookingFormInput,
  room: Room,
  seededInFirestore: boolean
): Promise<PublicBookingStatus> {
  const sig = createSubmissionSignature(input.mobile, input.roomId, input.preferredDate);
  const lastAt = recentSubmissions.get(sig);
  if (lastAt && Date.now() - lastAt < 120_000) {
    throw new Error('DUPLICATE_BOOKING');
  }

  const bookingId = makeDocId('bk');
  const bookingCode = generateBookingCode();
  const nowIso = new Date().toISOString();

  if (seededInFirestore) {
    try {
      const batch = writeBatch(db);
      const bookingPayload: Record<string, unknown> = {
        id: bookingId,
        bookingCode,
        studentName: input.studentName,
        mobile: input.mobile,
        guardianMobile: input.guardianMobile,
        institution: input.institution,
        roomId: room.id,
        roomType: room.titleBn,
        occupants: input.occupants,
        preferredDate: input.preferredDate,
        status: 'pending',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      };
      if (input.message && input.message.trim().length > 0) {
        bookingPayload.message = input.message.trim();
      }

      batch.set(doc(db, 'bookings', bookingId), bookingPayload);
      batch.set(doc(db, 'booking_status', bookingCode), {
        bookingCode,
        roomType: room.titleBn,
        preferredDate: input.preferredDate,
        status: 'pending',
        createdAt: serverTimestamp(),
        updatedAt: serverTimestamp(),
      });

      await batch.commit();
      recentSubmissions.set(sig, Date.now());
      return {
        bookingCode,
        roomType: room.titleBn,
        preferredDate: input.preferredDate,
        status: 'pending',
        createdAt: nowIso,
        updatedAt: nowIso,
      };
    } catch (error) {
      handleFirestoreError(error, OperationType.WRITE, `bookings/${bookingId}`);
    }
  }

  // Pre-seed backend persistence fallback when admin has not yet initialized Firestore catalog
  const res = await fetch('/api/bookings', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({
      ...input,
      id: bookingId,
      bookingCode,
      roomType: room.titleBn,
    }),
  });
  if (!res.ok) {
    const errBody = await res.json().catch(() => ({}));
    if (errBody.code === 'DUPLICATE_BOOKING') {
      throw new Error('DUPLICATE_BOOKING');
    }
    throw new Error(errBody.error || 'Failed to submit booking');
  }
  const saved = (await res.json()) as PublicBookingStatus;
  recentSubmissions.set(sig, Date.now());
  return saved;
}

export async function lookupBookingStatus(bookingCodeRaw: string): Promise<PublicBookingStatus | null> {
  const code = bookingCodeRaw.trim().toUpperCase();
  if (!/^[A-Z0-9\-]{6,32}$/.test(code)) {
    return null;
  }

  try {
    const apiPromise = fetch(`/api/booking-status/${encodeURIComponent(code)}`)
      .then(async (res) => (res.ok ? ((await res.json()) as PublicBookingStatus) : null))
      .catch(() => null);

    const firestorePromise = getDoc(doc(db, 'booking_status', code))
      .then((snap) => {
        if (!snap.exists()) return null;
        const d = snap.data();
        return {
          bookingCode: d.bookingCode,
          roomType: d.roomType,
          preferredDate: d.preferredDate,
          status: d.status as BookingStatusValue,
          createdAt: tsToIso(d.createdAt),
          updatedAt: tsToIso(d.updatedAt),
        } as PublicBookingStatus;
      })
      .catch(() => null);

    const [fsResult, apiResult] = await Promise.all([firestorePromise, apiPromise]);
    return fsResult || apiResult;
  } catch {
    return null;
  }
}

export async function submitContactInquiry(input: InquiryFormInput): Promise<void> {
  const inquiryId = makeDocId('inq');
  try {
    await setDoc(doc(db, 'inquiries', inquiryId), {
      id: inquiryId,
      senderName: input.senderName,
      phone: input.phone,
      subject: input.subject,
      message: input.message,
      status: 'new',
      createdAt: serverTimestamp(),
    });
    return;
  } catch (error) {
    // Fallback to Express API if offline or rules reject
    const res = await fetch('/api/inquiries', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ ...input, id: inquiryId }),
    });
    if (!res.ok) {
      handleFirestoreError(error, OperationType.CREATE, `inquiries/${inquiryId}`);
    }
  }
}

// ---------- ADMIN OPERATIONS ----------

export async function ensureAdminSeededAndSynced(): Promise<void> {
  const currentUser = auth.currentUser;
  if (!currentUser) return;

  try {
    const batch = writeBatch(db);
    let hasWrites = false;

    const adminRef = doc(db, 'admins', currentUser.uid);
    const adminSnap = await getDoc(adminRef);
    if (!adminSnap.exists()) {
      batch.set(adminRef, {
        uid: currentUser.uid,
        email: currentUser.email || BOOTSTRAPPED_ADMIN_EMAIL,
        displayName: currentUser.displayName || 'Hostel Administrator',
        phone: '01928949055',
        role: 'super_admin',
        designation: 'Managing Director',
        updatedAt: serverTimestamp(),
      });
      hasWrites = true;
    }

    const settingsSnap = await getDoc(doc(db, 'website_settings', 'main'));
    if (!settingsSnap.exists()) {
      batch.set(doc(db, 'website_settings', 'main'), {
        ...DEFAULT_SETTINGS,
        updatedAt: serverTimestamp(),
      });
      hasWrites = true;
    } else {
      const existingSettings = settingsSnap.data() as Partial<WebsiteSettings>;
      const legacyName =
        existingSettings.hostelNameBn === 'বিদ্যানিধি হোস্টেল' ||
        existingSettings.hostelName === 'Bidyanidhi Hostel';
      const legacyPhones =
        existingSettings.phones?.[0] === '01783807171' ||
        existingSettings.whatsappNumbers?.[0] === '01783807171';

      if (legacyName || legacyPhones) {
        batch.update(doc(db, 'website_settings', 'main'), {
          ...(legacyName
            ? {
                hostelName: DEFAULT_SETTINGS.hostelName,
                hostelNameBn: DEFAULT_SETTINGS.hostelNameBn,
                aboutBn: DEFAULT_SETTINGS.aboutBn,
                aboutEn: DEFAULT_SETTINGS.aboutEn,
                seoTitle: DEFAULT_SETTINGS.seoTitle,
                seoDescription: DEFAULT_SETTINGS.seoDescription,
                seoKeywords: DEFAULT_SETTINGS.seoKeywords,
              }
            : {}),
          ...(legacyPhones
            ? {
                phones: DEFAULT_SETTINGS.phones,
                whatsappNumbers: DEFAULT_SETTINGS.whatsappNumbers,
              }
            : {}),
          updatedAt: serverTimestamp(),
        });
        hasWrites = true;
      }
    }

    const roomsSnap = await getDocs(collection(db, 'rooms'));
    if (roomsSnap.empty) {
      for (const room of DEFAULT_ROOMS) {
        batch.set(doc(db, 'rooms', room.id), {
          ...room,
          updatedAt: serverTimestamp(),
        });
      }
      for (const img of DEFAULT_ROOM_IMAGES) {
        batch.set(doc(db, 'room_images', img.id), {
          ...img,
          createdAt: serverTimestamp(),
        });
      }
      hasWrites = true;
    }

    const facSnap = await getDocs(collection(db, 'facilities'));
    if (facSnap.empty) {
      for (const fac of DEFAULT_FACILITIES) {
        batch.set(doc(db, 'facilities', fac.id), fac);
      }
      hasWrites = true;
    }

    const galSnap = await getDocs(collection(db, 'gallery'));
    if (galSnap.empty) {
      for (const g of DEFAULT_GALLERY) {
        batch.set(doc(db, 'gallery', g.id), {
          ...g,
          createdAt: serverTimestamp(),
        });
      }
      hasWrites = true;
    }

    if (hasWrites) {
      await batch.commit();
    }

    // Sync any pre-seed bookings/inquiries from Express server into Firestore
    const syncRes = await fetch('/api/pending-sync');
    if (syncRes.ok) {
      const { bookings, inquiries } = (await syncRes.json()) as {
        bookings: BookingRecord[];
        inquiries: InquiryRecord[];
      };
      if (bookings.length > 0 || inquiries.length > 0) {
        const syncBatch = writeBatch(db);
        for (const b of bookings) {
          syncBatch.set(doc(db, 'bookings', b.id), {
            ...b,
            status: 'pending',
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
          syncBatch.set(doc(db, 'booking_status', b.bookingCode), {
            bookingCode: b.bookingCode,
            roomType: b.roomType,
            preferredDate: b.preferredDate,
            status: 'pending',
            createdAt: serverTimestamp(),
            updatedAt: serverTimestamp(),
          });
        }
        for (const inq of inquiries) {
          syncBatch.set(doc(db, 'inquiries', inq.id), {
            ...inq,
            status: 'new',
            createdAt: serverTimestamp(),
          });
        }
        await syncBatch.commit();
        await fetch('/api/pending-sync/clear', { method: 'POST' });
      }
    }
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, 'admin_seed');
  }
}

export async function fetchAdminDashboardData(): Promise<{
  bookings: BookingRecord[];
  inquiries: InquiryRecord[];
  testimonials: TestimonialItem[];
  adminProfile: AdminProfile | null;
}> {
  try {
    const uid = auth.currentUser?.uid;
    const [bookingsSnap, inquiriesSnap, testimonialsSnap, adminSnap] = await Promise.all([
      getDocs(query(collection(db, 'bookings'), orderBy('createdAt', 'desc'))),
      getDocs(query(collection(db, 'inquiries'), orderBy('createdAt', 'desc'))),
      getDocs(query(collection(db, 'testimonials'), orderBy('createdAt', 'desc'))),
      uid ? getDoc(doc(db, 'admins', uid)) : Promise.resolve(null),
    ]);

    return {
      bookings: bookingsSnap.docs.map((d) => ({
        ...(d.data() as BookingRecord),
        id: d.id,
        createdAt: tsToIso(d.data().createdAt),
        updatedAt: tsToIso(d.data().updatedAt),
      })),
      inquiries: inquiriesSnap.docs.map((d) => ({
        ...(d.data() as InquiryRecord),
        id: d.id,
        createdAt: tsToIso(d.data().createdAt),
      })),
      testimonials: testimonialsSnap.docs.map((d) => ({
        ...(d.data() as TestimonialItem),
        id: d.id,
        createdAt: tsToIso(d.data().createdAt),
      })),
      adminProfile: adminSnap && adminSnap.exists()
        ? {
            ...(adminSnap.data() as AdminProfile),
            updatedAt: tsToIso(adminSnap.data().updatedAt),
          }
        : null,
    };
  } catch (error) {
    handleFirestoreError(error, OperationType.LIST, 'admin_dashboard');
  }
}

export async function adminUpdateBookingStatus(
  booking: BookingRecord,
  newStatus: BookingStatusValue,
  adminNote: string,
  rooms: Room[]
): Promise<void> {
  try {
    const batch = writeBatch(db);
    const bookingRef = doc(db, 'bookings', booking.id);
    const statusRef = doc(db, 'booking_status', booking.bookingCode);

    batch.update(bookingRef, {
      status: newStatus,
      adminNote: adminNote.trim(),
      updatedAt: serverTimestamp(),
    });
    batch.update(statusRef, {
      status: newStatus,
      updatedAt: serverTimestamp(),
    });

    // Adjust seat counts cleanly when moving into or out of 'approved'
    const targetRoom = rooms.find((r) => r.id === booking.roomId);
    if (targetRoom) {
      let nextSeats = targetRoom.availableSeats;
      if (booking.status !== 'approved' && newStatus === 'approved') {
        nextSeats = Math.max(0, targetRoom.availableSeats - booking.occupants);
      } else if (booking.status === 'approved' && (newStatus === 'rejected' || newStatus === 'completed')) {
        nextSeats = Math.min(targetRoom.capacity, targetRoom.availableSeats + booking.occupants);
      }
      if (nextSeats !== targetRoom.availableSeats) {
        const nextAvailStatus =
          nextSeats === 0 ? 'full' : nextSeats <= 1 ? 'limited' : 'available';
        batch.update(doc(db, 'rooms', targetRoom.id), {
          availableSeats: nextSeats,
          availabilityStatus: nextAvailStatus,
          updatedAt: serverTimestamp(),
        });
      }
    }

    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `bookings/${booking.id}`);
  }
}

export async function adminDeleteBooking(booking: BookingRecord): Promise<void> {
  try {
    const batch = writeBatch(db);
    batch.delete(doc(db, 'bookings', booking.id));
    batch.delete(doc(db, 'booking_status', booking.bookingCode));
    await batch.commit();
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `bookings/${booking.id}`);
  }
}

export async function adminSaveRoom(room: Omit<Room, 'updatedAt'>): Promise<void> {
  try {
    await setDoc(doc(db, 'rooms', room.id), {
      ...room,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `rooms/${room.id}`);
  }
}

export async function adminDeleteRoom(roomId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'rooms', roomId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `rooms/${roomId}`);
  }
}

export async function adminSaveRoomImage(img: Omit<RoomImage, 'createdAt'>): Promise<void> {
  try {
    await setDoc(doc(db, 'room_images', img.id), {
      ...img,
      createdAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.CREATE, `room_images/${img.id}`);
  }
}

export async function adminDeleteRoomImage(imageId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'room_images', imageId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `room_images/${imageId}`);
  }
}

export async function adminSaveFacility(fac: FacilityItem): Promise<void> {
  try {
    await setDoc(doc(db, 'facilities', fac.id), fac);
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `facilities/${fac.id}`);
  }
}

export async function adminDeleteFacility(facilityId: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'facilities', facilityId));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `facilities/${facilityId}`);
  }
}

export async function adminSaveGalleryItem(item: Omit<GalleryItem, 'createdAt'>): Promise<void> {
  try {
    await setDoc(doc(db, 'gallery', item.id), {
      ...item,
      createdAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `gallery/${item.id}`);
  }
}

export async function adminDeleteGalleryItem(id: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'gallery', id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `gallery/${id}`);
  }
}

export async function adminSaveTestimonial(item: Omit<TestimonialItem, 'createdAt'>): Promise<void> {
  try {
    await setDoc(doc(db, 'testimonials', item.id), {
      ...item,
      createdAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `testimonials/${item.id}`);
  }
}

export async function adminDeleteTestimonial(id: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'testimonials', id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `testimonials/${id}`);
  }
}

export async function adminUpdateInquiryStatus(id: string, status: InquiryStatus): Promise<void> {
  try {
    await updateDoc(doc(db, 'inquiries', id), { status });
  } catch (error) {
    handleFirestoreError(error, OperationType.UPDATE, `inquiries/${id}`);
  }
}

export async function adminDeleteInquiry(id: string): Promise<void> {
  try {
    await deleteDoc(doc(db, 'inquiries', id));
  } catch (error) {
    handleFirestoreError(error, OperationType.DELETE, `inquiries/${id}`);
  }
}

export async function adminSaveWebsiteSettings(settings: Omit<WebsiteSettings, 'updatedAt'>): Promise<void> {
  try {
    await setDoc(doc(db, 'website_settings', 'main'), {
      ...settings,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, 'website_settings/main');
  }
}

export async function adminSaveAdminProfile(profile: Omit<AdminProfile, 'updatedAt'>): Promise<void> {
  try {
    await setDoc(doc(db, 'admins', profile.uid), {
      ...profile,
      updatedAt: serverTimestamp(),
    });
  } catch (error) {
    handleFirestoreError(error, OperationType.WRITE, `admins/${profile.uid}`);
  }
}
