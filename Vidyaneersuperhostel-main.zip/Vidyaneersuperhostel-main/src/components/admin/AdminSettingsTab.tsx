import { useState } from 'react';
import { Check, Download, Shield, Trash2 } from 'lucide-react';
import { useApp } from '../../contexts/AppContext';
import {
  adminDeleteInquiry,
  adminSaveAdminProfile,
  adminSaveWebsiteSettings,
  adminUpdateInquiryStatus,
} from '../../services/hostelService';
import type { AdminProfile, BookingRecord, InquiryRecord, InquiryStatus } from '../../types/hostel';

interface AdminSettingsTabProps {
  inquiries: InquiryRecord[];
  bookings: BookingRecord[];
  adminProfile: AdminProfile | null;
  onRefreshAdmin: () => Promise<void>;
}

export function AdminSettingsTab({
  inquiries,
  bookings,
  adminProfile,
  onRefreshAdmin,
}: AdminSettingsTabProps) {
  const { settings, rooms, facilities, gallery, user, refreshPublicData } = useApp();

  const [formSettings, setFormSettings] = useState(settings);
  const [phonesText, setPhonesText] = useState(settings.phones.join(', '));
  const [waText, setWaText] = useState(settings.whatsappNumbers.join(', '));

  const [displayName, setDisplayName] = useState(
    adminProfile?.displayName || user?.displayName || 'Hostel Administrator'
  );
  const [adminPhone, setAdminPhone] = useState(adminProfile?.phone || '01928949055');
  const [designation, setDesignation] = useState(adminProfile?.designation || 'Managing Director');

  const [saving, setSaving] = useState(false);
  const [savedNotice, setSavedNotice] = useState<string | null>(null);

  const handleSaveSettings = async () => {
    setSaving(true);
    setSavedNotice(null);
    try {
      const phones = phonesText
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean)
        .slice(0, 5);
      const whatsappNumbers = waText
        .split(',')
        .map((s) => s.trim())
        .filter(Boolean)
        .slice(0, 5);

      const { updatedAt: _u, ...rest } = formSettings;
      await adminSaveWebsiteSettings({
        ...rest,
        phones: phones.length ? phones : ['01928949055', '01671948750'],
        whatsappNumbers: whatsappNumbers.length ? whatsappNumbers : ['01928949055', '01671948750'],
      });
      await refreshPublicData();
      setSavedNotice('Website content, phone numbers, and SEO settings saved.');
    } finally {
      setSaving(false);
    }
  };

  const handleSaveProfile = async () => {
    if (!user) return;
    setSaving(true);
    setSavedNotice(null);
    try {
      await adminSaveAdminProfile({
        uid: user.uid,
        email: user.email || '',
        displayName: displayName.trim() || 'Administrator',
        phone: adminPhone.trim(),
        role: adminProfile?.role || 'super_admin',
        designation: designation.trim(),
      });
      await onRefreshAdmin();
      setSavedNotice('Admin profile updated.');
    } finally {
      setSaving(false);
    }
  };

  const handleDownloadBackup = () => {
    const backup = {
      exportedAt: new Date().toISOString(),
      settings,
      rooms,
      facilities,
      gallery,
      bookings,
      inquiries,
    };
    const blob = new Blob([JSON.stringify(backup, null, 2)], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const a = document.createElement('a');
    a.href = url;
    a.download = `bidya-neer-super-hostel-backup-${new Date().toISOString().slice(0, 10)}.json`;
    a.click();
    URL.revokeObjectURL(url);
  };

  return (
    <div className="space-y-10">
      {savedNotice && (
        <div className="p-3.5 rounded-lg bg-emerald-50 border border-emerald-200 text-sm text-emerald-900 flex items-center gap-2">
          <Check className="w-4 h-4 text-emerald-700" />
          <span>{savedNotice}</span>
        </div>
      )}

      {/* 1. Contact Inquiries */}
      <section className="space-y-4">
        <div>
          <h2 className="text-xl font-bold text-[#0F2342]">Contact Inquiries ({inquiries.length})</h2>
          <p className="text-sm text-slate-600">Messages submitted via the public contact form.</p>
        </div>

        {inquiries.length === 0 ? (
          <div className="bg-white border border-slate-200 rounded-xl p-8 text-center text-sm text-slate-500">
            No contact inquiries received yet.
          </div>
        ) : (
          <div className="bg-white border border-slate-200 rounded-xl overflow-x-auto">
            <table className="w-full text-left border-collapse text-sm">
              <thead>
                <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                  <th className="py-3 px-4">Sender</th>
                  <th className="py-3 px-4">Phone</th>
                  <th className="py-3 px-4">Subject & Message</th>
                  <th className="py-3 px-4">Status</th>
                  <th className="py-3 px-4 text-right">Delete</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-slate-100">
                {inquiries.map((inq) => (
                  <tr key={inq.id} className="align-top">
                    <td className="py-3 px-4 font-semibold text-[#0F2342]">{inq.senderName}</td>
                    <td className="py-3 px-4 font-mono-tabular text-xs">{inq.phone}</td>
                    <td className="py-3 px-4 max-w-md">
                      <div className="font-medium text-slate-900">{inq.subject}</div>
                      <p className="text-xs text-slate-600 mt-0.5">{inq.message}</p>
                    </td>
                    <td className="py-3 px-4">
                      <select
                        value={inq.status}
                        onChange={(e) =>
                          adminUpdateInquiryStatus(inq.id, e.target.value as InquiryStatus).then(
                            onRefreshAdmin
                          )
                        }
                        className="px-2 py-1 text-xs border border-slate-300 rounded bg-white"
                      >
                        <option value="new">New</option>
                        <option value="read">Read</option>
                        <option value="replied">Replied</option>
                      </select>
                    </td>
                    <td className="py-3 px-4 text-right">
                      <button
                        type="button"
                        onClick={() => adminDeleteInquiry(inq.id).then(onRefreshAdmin)}
                        className="text-rose-600 hover:text-rose-800"
                        aria-label={`Delete inquiry from ${inq.senderName}`}
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </section>

      {/* 2. Website Content, Phone Numbers & SEO Settings */}
      <section className="bg-white border border-slate-200 rounded-xl p-6 space-y-5">
        <div>
          <h2 className="text-xl font-bold text-[#0F2342]">
            Website Content, Phone Numbers & SEO Settings
          </h2>
          <p className="text-sm text-slate-600">
            Update public hero text, about text, address, contact numbers, and SEO metadata.
          </p>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Phone Numbers (comma-separated)
            </label>
            <input
              type="text"
              value={phonesText}
              onChange={(e) => setPhonesText(e.target.value)}
              className="w-full px-3 py-2 text-sm font-mono-tabular border border-slate-300 rounded-lg"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              WhatsApp Numbers (comma-separated)
            </label>
            <input
              type="text"
              value={waText}
              onChange={(e) => setWaText(e.target.value)}
              className="w-full px-3 py-2 text-sm font-mono-tabular border border-slate-300 rounded-lg"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Hero Heading (Bengali)
            </label>
            <input
              type="text"
              value={formSettings.heroHeadingBn}
              onChange={(e) => setFormSettings({ ...formSettings, heroHeadingBn: e.target.value })}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Hero Heading (English)
            </label>
            <input
              type="text"
              value={formSettings.heroHeadingEn}
              onChange={(e) => setFormSettings({ ...formSettings, heroHeadingEn: e.target.value })}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              Address (Bengali)
            </label>
            <input
              type="text"
              value={formSettings.addressBn}
              onChange={(e) => setFormSettings({ ...formSettings, addressBn: e.target.value })}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">
              SEO Page Title
            </label>
            <input
              type="text"
              value={formSettings.seoTitle}
              onChange={(e) => setFormSettings({ ...formSettings, seoTitle: e.target.value })}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
            />
          </div>
        </div>

        <div>
          <label className="block text-xs font-semibold text-slate-700 mb-1">
            SEO Meta Description
          </label>
          <textarea
            rows={2}
            value={formSettings.seoDescription}
            onChange={(e) => setFormSettings({ ...formSettings, seoDescription: e.target.value })}
            className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
          />
        </div>

        <button
          type="button"
          disabled={saving}
          onClick={handleSaveSettings}
          className="px-5 py-2.5 text-sm font-semibold text-white bg-[#0F2342] hover:bg-[#193766] rounded-lg"
        >
          {saving ? 'Saving...' : 'Save Website & SEO Settings'}
        </button>
      </section>

      {/* 3. Admin Profile, Security & Backup */}
      <section className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
          <h3 className="text-lg font-bold text-[#0F2342]">Admin Profile</h3>
          <div className="space-y-3">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Display Name</label>
              <input
                type="text"
                value={displayName}
                onChange={(e) => setDisplayName(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Contact Phone</label>
              <input
                type="text"
                value={adminPhone}
                onChange={(e) => setAdminPhone(e.target.value)}
                className="w-full px-3 py-2 text-sm font-mono-tabular border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Designation</label>
              <input
                type="text"
                value={designation}
                onChange={(e) => setDesignation(e.target.value)}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
              />
            </div>
            <button
              type="button"
              disabled={saving}
              onClick={handleSaveProfile}
              className="px-4 py-2 text-sm font-semibold text-white bg-[#0F2342] rounded-lg"
            >
              Update Admin Profile
            </button>
          </div>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-4">
          <div className="flex items-center gap-2 text-[#0F2342]">
            <Shield className="w-5 h-5 text-[#D99B26]" />
            <h3 className="text-lg font-bold">Security, Access & Database Backup</h3>
          </div>
          <p className="text-sm text-slate-600 leading-relaxed">
            Admin access is secured via verified Google Authentication and Firestore role-based
            rules. Manage password & 2-Step Verification through your Google Account security
            settings, and export a JSON snapshot of hostel records before major updates.
          </p>
          <button
            type="button"
            onClick={handleDownloadBackup}
            className="inline-flex items-center gap-2 px-4 py-2.5 text-sm font-semibold text-[#0F2342] bg-[#D99B26] hover:bg-[#c58a1c] rounded-lg"
          >
            <Download className="w-4 h-4" />
            Export JSON Database Backup
          </button>
        </div>
      </section>
    </div>
  );
}
