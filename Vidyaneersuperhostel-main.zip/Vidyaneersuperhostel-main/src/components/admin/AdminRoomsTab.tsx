import { useState } from 'react';
import { Check, Edit3, Plus, Trash2 } from 'lucide-react';
import { useApp } from '../../contexts/AppContext';
import {
  adminDeleteRoom,
  adminDeleteRoomImage,
  adminSaveRoom,
  adminSaveRoomImage,
} from '../../services/hostelService';
import type { AvailabilityStatus, Room, RoomCategory } from '../../types/hostel';

export function AdminRoomsTab() {
  const { rooms, roomImages, refreshPublicData } = useApp();
  const [editingRoom, setEditingRoom] = useState<Room | null>(null);
  const [saving, setSaving] = useState(false);
  const [statusMsg, setStatusMsg] = useState<string | null>(null);
  const [newImgUrl, setNewImgUrl] = useState('');
  const [newImgCaption, setNewImgCaption] = useState('');

  const startNewRoom = () => {
    setEditingRoom({
      id: `room-${Date.now()}`,
      category: 'single',
      titleBn: 'নতুন রুম',
      titleEn: 'New Room',
      descriptionBn: 'রুমের বিস্তারিত বিবরণ লিখুন।',
      descriptionEn: 'Enter room description.',
      capacity: 1,
      availableSeats: 1,
      monthlyRent: null,
      priceConfirmed: false,
      pricePlaceholderBn: 'যোগাযোগ সাপেক্ষে',
      pricePlaceholderEn: 'Contact for Fee',
      availabilityStatus: 'available',
      facilitiesBn: ['পড়ার টেবিল', 'আলো-বাতাসপূর্ণ'],
      facilitiesEn: ['Study desk', 'Natural ventilation'],
      primaryImage: rooms[0]?.primaryImage || '',
      sortOrder: rooms.length + 1,
      updatedAt: new Date().toISOString(),
    });
  };

  const handleSave = async () => {
    if (!editingRoom) return;
    setSaving(true);
    setStatusMsg(null);
    try {
      const { updatedAt: _u, ...payload } = editingRoom;
      await adminSaveRoom(payload);
      await refreshPublicData();
      setStatusMsg('Room saved to Firestore.');
      setEditingRoom(null);
    } finally {
      setSaving(false);
    }
  };

  const handleQuickUpdate = async (room: Room, patch: Partial<Room>) => {
    setSaving(true);
    try {
      const { updatedAt: _u, ...rest } = { ...room, ...patch };
      await adminSaveRoom(rest);
      await refreshPublicData();
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (roomId: string) => {
    setSaving(true);
    try {
      await adminDeleteRoom(roomId);
      await refreshPublicData();
    } finally {
      setSaving(false);
    }
  };

  const handleAddImage = async (roomId: string) => {
    if (!newImgUrl.trim()) return;
    setSaving(true);
    try {
      await adminSaveRoomImage({
        id: `ri-${Date.now()}`,
        roomId,
        imageUrl: newImgUrl.trim(),
        captionBn: newImgCaption.trim(),
        captionEn: newImgCaption.trim(),
        sortOrder: roomImages.filter((i) => i.roomId === roomId).length + 1,
      });
      setNewImgUrl('');
      setNewImgCaption('');
      await refreshPublicData();
    } finally {
      setSaving(false);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-wrap items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-[#0F2342]">Rooms, Availability & Pricing</h2>
          <p className="text-sm text-slate-600">
            Manage room capacities, available seats, confirmed monthly rent, and room photos.
          </p>
        </div>
        <button
          type="button"
          onClick={startNewRoom}
          className="inline-flex items-center gap-2 px-4 py-2 text-sm font-semibold text-white bg-[#0F2342] hover:bg-[#193766] rounded-lg"
        >
          <Plus className="w-4 h-4" />
          Add Room Category
        </button>
      </div>

      {statusMsg && (
        <div className="p-3 rounded-lg bg-emerald-50 border border-emerald-200 text-sm text-emerald-900 flex items-center gap-2">
          <Check className="w-4 h-4 text-emerald-700" />
          <span>{statusMsg}</span>
        </div>
      )}

      {editingRoom && (
        <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-5">
          <div className="flex items-center justify-between">
            <h3 className="text-base font-bold text-[#0F2342]">Edit Room: {editingRoom.titleEn}</h3>
            <button
              type="button"
              onClick={() => setEditingRoom(null)}
              className="text-xs font-semibold text-slate-500 hover:text-slate-800"
            >
              Cancel
            </button>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Category</label>
              <select
                value={editingRoom.category}
                onChange={(e) =>
                  setEditingRoom({ ...editingRoom, category: e.target.value as RoomCategory })
                }
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white"
              >
                <option value="single">Single Room</option>
                <option value="double">Double Sharing</option>
                <option value="multiple">Multiple Sharing</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Title (Bengali)</label>
              <input
                type="text"
                value={editingRoom.titleBn}
                onChange={(e) => setEditingRoom({ ...editingRoom, titleBn: e.target.value })}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Title (English)</label>
              <input
                type="text"
                value={editingRoom.titleEn}
                onChange={(e) => setEditingRoom({ ...editingRoom, titleEn: e.target.value })}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
              />
            </div>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Description (Bengali)</label>
              <textarea
                rows={3}
                value={editingRoom.descriptionBn}
                onChange={(e) => setEditingRoom({ ...editingRoom, descriptionBn: e.target.value })}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Description (English)</label>
              <textarea
                rows={3}
                value={editingRoom.descriptionEn}
                onChange={(e) => setEditingRoom({ ...editingRoom, descriptionEn: e.target.value })}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
              />
            </div>
          </div>

          <div className="grid grid-cols-2 sm:grid-cols-4 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Capacity</label>
              <input
                type="number"
                min={1}
                max={20}
                value={editingRoom.capacity}
                onChange={(e) => setEditingRoom({ ...editingRoom, capacity: Number(e.target.value) })}
                className="w-full px-3 py-2 text-sm font-mono-tabular border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Available Seats</label>
              <input
                type="number"
                min={0}
                max={20}
                value={editingRoom.availableSeats}
                onChange={(e) =>
                  setEditingRoom({ ...editingRoom, availableSeats: Number(e.target.value) })
                }
                className="w-full px-3 py-2 text-sm font-mono-tabular border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Availability</label>
              <select
                value={editingRoom.availabilityStatus}
                onChange={(e) =>
                  setEditingRoom({
                    ...editingRoom,
                    availabilityStatus: e.target.value as AvailabilityStatus,
                  })
                }
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white"
              >
                <option value="available">Available</option>
                <option value="limited">Limited</option>
                <option value="full">Full</option>
                <option value="maintenance">Maintenance</option>
              </select>
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Monthly Rent (BDT)</label>
              <input
                type="number"
                min={0}
                value={editingRoom.monthlyRent ?? ''}
                placeholder="Unset"
                onChange={(e) =>
                  setEditingRoom({
                    ...editingRoom,
                    monthlyRent: e.target.value ? Number(e.target.value) : null,
                  })
                }
                className="w-full px-3 py-2 text-sm font-mono-tabular border border-slate-300 rounded-lg"
              />
            </div>
          </div>

          <div className="flex flex-wrap items-center gap-4">
            <label className="inline-flex items-center gap-2 text-sm font-medium text-[#0F2342]">
              <input
                type="checkbox"
                checked={editingRoom.priceConfirmed}
                onChange={(e) => setEditingRoom({ ...editingRoom, priceConfirmed: e.target.checked })}
                className="rounded border-slate-300"
              />
              Publish Confirmed Monthly Rent (uncheck to show placeholder text)
            </label>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">Primary Image URL</label>
              <input
                type="text"
                value={editingRoom.primaryImage}
                onChange={(e) => setEditingRoom({ ...editingRoom, primaryImage: e.target.value })}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
              />
            </div>
            <div>
              <label className="block text-xs font-semibold text-slate-700 mb-1">
                Placeholder Fee Label (BN)
              </label>
              <input
                type="text"
                value={editingRoom.pricePlaceholderBn}
                onChange={(e) => setEditingRoom({ ...editingRoom, pricePlaceholderBn: e.target.value })}
                className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
              />
            </div>
          </div>

          {/* Room Gallery Images Sub-manager */}
          <div className="pt-4 border-t border-slate-200 space-y-3">
            <h4 className="text-xs font-bold text-[#0F2342] uppercase tracking-wider">
              Additional Room Photos ({roomImages.filter((i) => i.roomId === editingRoom.id).length})
            </h4>
            <div className="flex flex-wrap gap-3">
              {roomImages
                .filter((i) => i.roomId === editingRoom.id)
                .map((img) => (
                  <div
                    key={img.id}
                    className="flex items-center gap-2 px-3 py-1.5 bg-slate-50 border border-slate-200 rounded-lg text-xs"
                  >
                    <span className="truncate max-w-[180px]">{img.captionEn || img.imageUrl}</span>
                    <button
                      type="button"
                      onClick={() => adminDeleteRoomImage(img.id).then(refreshPublicData)}
                      className="text-rose-600 hover:text-rose-800"
                      aria-label="Delete room image"
                    >
                      <Trash2 className="w-3.5 h-3.5" />
                    </button>
                  </div>
                ))}
            </div>
            <div className="flex flex-col sm:flex-row gap-2">
              <input
                type="text"
                value={newImgUrl}
                onChange={(e) => setNewImgUrl(e.target.value)}
                placeholder="Image URL"
                className="flex-1 px-3 py-1.5 text-xs border border-slate-300 rounded-lg"
              />
              <input
                type="text"
                value={newImgCaption}
                onChange={(e) => setNewImgCaption(e.target.value)}
                placeholder="Caption"
                className="sm:w-48 px-3 py-1.5 text-xs border border-slate-300 rounded-lg"
              />
              <button
                type="button"
                onClick={() => handleAddImage(editingRoom.id)}
                className="px-3 py-1.5 text-xs font-semibold text-[#0F2342] bg-[#D99B26] rounded-lg"
              >
                Add Photo
              </button>
            </div>
          </div>

          <div className="flex justify-end gap-3 pt-2">
            <button
              type="button"
              disabled={saving}
              onClick={handleSave}
              className="px-5 py-2.5 text-sm font-semibold text-white bg-[#0F2342] hover:bg-[#193766] rounded-lg disabled:opacity-60"
            >
              {saving ? 'Saving...' : 'Save Room'}
            </button>
          </div>
        </div>
      )}

      {/* Room Table */}
      <div className="bg-white border border-slate-200 rounded-xl overflow-x-auto">
        <table className="w-full text-left border-collapse text-sm">
          <thead>
            <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
              <th className="py-3 px-4">Room</th>
              <th className="py-3 px-4">Capacity / Seats</th>
              <th className="py-3 px-4">Status</th>
              <th className="py-3 px-4">Monthly Fee</th>
              <th className="py-3 px-4 text-right">Actions</th>
            </tr>
          </thead>
          <tbody className="divide-y divide-slate-100">
            {rooms.map((room) => (
              <tr key={room.id} className="hover:bg-slate-50/70">
                <td className="py-3 px-4">
                  <div className="font-semibold text-[#0F2342]">{room.titleEn}</div>
                  <div className="text-xs text-slate-500">{room.titleBn}</div>
                </td>
                <td className="py-3 px-4 font-mono-tabular">
                  <div className="flex items-center gap-2">
                    <span>{room.availableSeats} / {room.capacity}</span>
                    <button
                      type="button"
                      disabled={saving}
                      onClick={() =>
                        handleQuickUpdate(room, {
                          availableSeats: Math.max(0, room.availableSeats - 1),
                        })
                      }
                      className="px-1.5 py-0.5 text-xs border border-slate-300 rounded hover:bg-slate-100"
                      aria-label={`Decrease seats for ${room.titleEn}`}
                    >
                      -
                    </button>
                    <button
                      type="button"
                      disabled={saving}
                      onClick={() =>
                        handleQuickUpdate(room, {
                          availableSeats: Math.min(room.capacity, room.availableSeats + 1),
                        })
                      }
                      className="px-1.5 py-0.5 text-xs border border-slate-300 rounded hover:bg-slate-100"
                      aria-label={`Increase seats for ${room.titleEn}`}
                    >
                      +
                    </button>
                  </div>
                </td>
                <td className="py-3 px-4">
                  <select
                    value={room.availabilityStatus}
                    disabled={saving}
                    onChange={(e) =>
                      handleQuickUpdate(room, {
                        availabilityStatus: e.target.value as AvailabilityStatus,
                      })
                    }
                    className="px-2.5 py-1 text-xs border border-slate-300 rounded-md bg-white"
                  >
                    <option value="available">Available</option>
                    <option value="limited">Limited</option>
                    <option value="full">Full</option>
                    <option value="maintenance">Maintenance</option>
                  </select>
                </td>
                <td className="py-3 px-4 font-mono-tabular">
                  {room.priceConfirmed && room.monthlyRent !== null
                    ? `৳${room.monthlyRent.toLocaleString()}`
                    : 'Placeholder'}
                </td>
                <td className="py-3 px-4 text-right space-x-2 whitespace-nowrap">
                  <button
                    type="button"
                    onClick={() => setEditingRoom(room)}
                    className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-[#0F2342] border border-slate-300 rounded-md hover:bg-slate-50"
                  >
                    <Edit3 className="w-3.5 h-3.5" />
                    Edit
                  </button>
                  <button
                    type="button"
                    onClick={() => handleDelete(room.id)}
                    className="inline-flex items-center gap-1 px-2.5 py-1.5 text-xs font-medium text-rose-700 border border-rose-200 rounded-md hover:bg-rose-50"
                  >
                    <Trash2 className="w-3.5 h-3.5" />
                    Delete
                  </button>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </div>
  );
}
