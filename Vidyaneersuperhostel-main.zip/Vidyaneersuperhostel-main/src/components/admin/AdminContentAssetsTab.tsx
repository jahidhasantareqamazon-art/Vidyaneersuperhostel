import { useState } from 'react';
import { Check, Plus, Trash2 } from 'lucide-react';
import { useApp } from '../../contexts/AppContext';
import {
  adminDeleteFacility,
  adminDeleteGalleryItem,
  adminDeleteTestimonial,
  adminSaveFacility,
  adminSaveGalleryItem,
  adminSaveTestimonial,
} from '../../services/hostelService';
import type { GalleryCategory, TestimonialItem } from '../../types/hostel';

interface AdminContentAssetsTabProps {
  allTestimonials: TestimonialItem[];
  onRefreshAdmin: () => Promise<void>;
}

export function AdminContentAssetsTab({
  allTestimonials,
  onRefreshAdmin,
}: AdminContentAssetsTabProps) {
  const { facilities, gallery, refreshPublicData } = useApp();
  const [busy, setBusy] = useState(false);

  // New Gallery form state
  const [galTitleBn, setGalTitleBn] = useState('');
  const [galTitleEn, setGalTitleEn] = useState('');
  const [galCategory, setGalCategory] = useState<GalleryCategory>('rooms');
  const [galUrl, setGalUrl] = useState('');

  // New Testimonial form state
  const [authorName, setAuthorName] = useState('');
  const [roleBn, setRoleBn] = useState('');
  const [roleEn, setRoleEn] = useState('');
  const [institution, setInstitution] = useState('');
  const [quoteBn, setQuoteBn] = useState('');
  const [quoteEn, setQuoteEn] = useState('');

  const handleToggleFacility = async (
    id: string,
    field: 'isConfirmed' | 'isActive',
    nextVal: boolean
  ) => {
    const item = facilities.find((f) => f.id === id);
    if (!item) return;
    setBusy(true);
    try {
      await adminSaveFacility({ ...item, [field]: nextVal });
      await refreshPublicData();
    } finally {
      setBusy(false);
    }
  };

  const handleAddGallery = async () => {
    if (!galTitleBn.trim() || !galTitleEn.trim() || !galUrl.trim()) return;
    setBusy(true);
    try {
      await adminSaveGalleryItem({
        id: `gal-${Date.now()}`,
        category: galCategory,
        titleBn: galTitleBn.trim(),
        titleEn: galTitleEn.trim(),
        imageUrl: galUrl.trim(),
        sortOrder: gallery.length + 1,
      });
      setGalTitleBn('');
      setGalTitleEn('');
      setGalUrl('');
      await refreshPublicData();
    } finally {
      setBusy(false);
    }
  };

  const handleAddTestimonial = async () => {
    if (!authorName.trim() || !quoteBn.trim() || !quoteEn.trim()) return;
    setBusy(true);
    try {
      await adminSaveTestimonial({
        id: `test-${Date.now()}`,
        authorName: authorName.trim(),
        roleBn: roleBn.trim() || 'শিক্ষার্থী',
        roleEn: roleEn.trim() || 'Resident Student',
        institution: institution.trim() || 'Narsingdi Govt. College',
        quoteBn: quoteBn.trim(),
        quoteEn: quoteEn.trim(),
        isPublished: true,
      });
      setAuthorName('');
      setRoleBn('');
      setRoleEn('');
      setInstitution('');
      setQuoteBn('');
      setQuoteEn('');
      await Promise.all([onRefreshAdmin(), refreshPublicData()]);
    } finally {
      setBusy(false);
    }
  };

  return (
    <div className="space-y-10">
      {/* 1. Facilities Management */}
      <section className="space-y-4">
        <div>
          <h2 className="text-xl font-bold text-[#0F2342]">Facilities Management</h2>
          <p className="text-sm text-slate-600">
            Confirm optional facilities like Wi-Fi and Dining only when officially active.
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                <th className="py-3 px-4">Facility</th>
                <th className="py-3 px-4">Confirmed Status</th>
                <th className="py-3 px-4">Visible on Site</th>
                <th className="py-3 px-4 text-right">Remove</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {facilities.map((fac) => (
                <tr key={fac.id}>
                  <td className="py-3 px-4">
                    <div className="font-semibold text-[#0F2342]">{fac.titleEn}</div>
                    <div className="text-xs text-slate-500">{fac.titleBn}</div>
                  </td>
                  <td className="py-3 px-4">
                    <button
                      type="button"
                      disabled={busy}
                      onClick={() => handleToggleFacility(fac.id, 'isConfirmed', !fac.isConfirmed)}
                      className={`inline-flex items-center gap-1.5 px-3 py-1 text-xs font-semibold rounded-md border ${
                        fac.isConfirmed
                          ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                          : 'bg-amber-50 text-amber-800 border-amber-200'
                      }`}
                    >
                      <Check className="w-3.5 h-3.5" />
                      {fac.isConfirmed ? 'Confirmed' : 'Pending Confirmation'}
                    </button>
                  </td>
                  <td className="py-3 px-4">
                    <input
                      type="checkbox"
                      checked={fac.isActive}
                      disabled={busy}
                      onChange={(e) => handleToggleFacility(fac.id, 'isActive', e.target.checked)}
                      aria-label={`Toggle visibility for ${fac.titleEn}`}
                    />
                  </td>
                  <td className="py-3 px-4 text-right">
                    <button
                      type="button"
                      disabled={busy}
                      onClick={() => adminDeleteFacility(fac.id).then(refreshPublicData)}
                      className="text-rose-600 hover:text-rose-800"
                      aria-label={`Delete ${fac.titleEn}`}
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </section>

      {/* 2. Gallery Management */}
      <section className="space-y-4">
        <div>
          <h2 className="text-xl font-bold text-[#0F2342]">Gallery Management</h2>
          <p className="text-sm text-slate-600">Add or remove hostel building, room, and common space photos.</p>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5 grid grid-cols-1 sm:grid-cols-5 gap-3 items-end">
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Category</label>
            <select
              value={galCategory}
              onChange={(e) => setGalCategory(e.target.value as GalleryCategory)}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg bg-white"
            >
              <option value="rooms">Rooms</option>
              <option value="building">Building</option>
              <option value="common">Common</option>
              <option value="facilities">Facilities</option>
            </select>
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Title (BN)</label>
            <input
              type="text"
              value={galTitleBn}
              onChange={(e) => setGalTitleBn(e.target.value)}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Title (EN)</label>
            <input
              type="text"
              value={galTitleEn}
              onChange={(e) => setGalTitleEn(e.target.value)}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
            />
          </div>
          <div>
            <label className="block text-xs font-semibold text-slate-700 mb-1">Image URL</label>
            <input
              type="text"
              value={galUrl}
              onChange={(e) => setGalUrl(e.target.value)}
              className="w-full px-3 py-2 text-sm border border-slate-300 rounded-lg"
            />
          </div>
          <button
            type="button"
            disabled={busy}
            onClick={handleAddGallery}
            className="inline-flex items-center justify-center gap-1.5 px-4 py-2 text-sm font-semibold text-white bg-[#0F2342] rounded-lg hover:bg-[#193766]"
          >
            <Plus className="w-4 h-4" />
            Add Photo
          </button>
        </div>

        <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
          {gallery.map((g) => (
            <div
              key={g.id}
              className="bg-white border border-slate-200 rounded-xl p-4 flex items-center justify-between gap-3"
            >
              <div className="min-w-0">
                <span className="text-xs text-slate-500 capitalize">{g.category}</span>
                <p className="text-sm font-semibold text-[#0F2342] truncate">{g.titleEn}</p>
              </div>
              <button
                type="button"
                disabled={busy}
                onClick={() => adminDeleteGalleryItem(g.id).then(refreshPublicData)}
                className="text-rose-600 hover:text-rose-800 shrink-0"
                aria-label={`Delete gallery item ${g.titleEn}`}
              >
                <Trash2 className="w-4 h-4" />
              </button>
            </div>
          ))}
        </div>
      </section>

      {/* 3. Testimonials Management */}
      <section className="space-y-4">
        <div>
          <h2 className="text-xl font-bold text-[#0F2342]">Testimonials Management</h2>
          <p className="text-sm text-slate-600">
            Publish verified student or guardian testimonials. Unpublished reviews remain hidden.
          </p>
        </div>

        <div className="bg-white border border-slate-200 rounded-xl p-5 space-y-4">
          <div className="grid grid-cols-1 sm:grid-cols-4 gap-3">
            <input
              type="text"
              placeholder="Author Name"
              value={authorName}
              onChange={(e) => setAuthorName(e.target.value)}
              className="px-3 py-2 text-sm border border-slate-300 rounded-lg"
            />
            <input
              type="text"
              placeholder="Role (BN)"
              value={roleBn}
              onChange={(e) => setRoleBn(e.target.value)}
              className="px-3 py-2 text-sm border border-slate-300 rounded-lg"
            />
            <input
              type="text"
              placeholder="Role (EN)"
              value={roleEn}
              onChange={(e) => setRoleEn(e.target.value)}
              className="px-3 py-2 text-sm border border-slate-300 rounded-lg"
            />
            <input
              type="text"
              placeholder="College / Institution"
              value={institution}
              onChange={(e) => setInstitution(e.target.value)}
              className="px-3 py-2 text-sm border border-slate-300 rounded-lg"
            />
          </div>
          <div className="grid grid-cols-1 sm:grid-cols-2 gap-3">
            <textarea
              rows={2}
              placeholder="Verified Quote (Bengali)"
              value={quoteBn}
              onChange={(e) => setQuoteBn(e.target.value)}
              className="px-3 py-2 text-sm border border-slate-300 rounded-lg"
            />
            <textarea
              rows={2}
              placeholder="Verified Quote (English)"
              value={quoteEn}
              onChange={(e) => setQuoteEn(e.target.value)}
              className="px-3 py-2 text-sm border border-slate-300 rounded-lg"
            />
          </div>
          <button
            type="button"
            disabled={busy}
            onClick={handleAddTestimonial}
            className="inline-flex items-center gap-1.5 px-4 py-2 text-sm font-semibold text-white bg-[#0F2342] rounded-lg"
          >
            <Plus className="w-4 h-4" />
            Publish Verified Testimonial
          </button>
        </div>

        <div className="space-y-3">
          {allTestimonials.length === 0 ? (
            <p className="text-sm text-slate-500">No testimonials added yet.</p>
          ) : (
            allTestimonials.map((item) => (
              <div
                key={item.id}
                className="bg-white border border-slate-200 rounded-xl p-4 flex flex-col sm:flex-row sm:items-center justify-between gap-4"
              >
                <div className="space-y-1">
                  <div className="font-semibold text-sm text-[#0F2342]">
                    {item.authorName} · {item.institution}
                  </div>
                  <p className="text-xs text-slate-600">{item.quoteEn}</p>
                </div>
                <div className="flex items-center gap-2 shrink-0">
                  <button
                    type="button"
                    disabled={busy}
                    onClick={async () => {
                      const { createdAt: _c, ...rest } = item;
                      await adminSaveTestimonial({ ...rest, isPublished: !item.isPublished });
                      await Promise.all([onRefreshAdmin(), refreshPublicData()]);
                    }}
                    className={`px-3 py-1 text-xs font-semibold rounded-md border ${
                      item.isPublished
                        ? 'bg-emerald-50 text-emerald-800 border-emerald-200'
                        : 'bg-slate-100 text-slate-700 border-slate-300'
                    }`}
                  >
                    {item.isPublished ? 'Published' : 'Hidden'}
                  </button>
                  <button
                    type="button"
                    disabled={busy}
                    onClick={async () => {
                      await adminDeleteTestimonial(item.id);
                      await Promise.all([onRefreshAdmin(), refreshPublicData()]);
                    }}
                    className="text-rose-600 hover:text-rose-800"
                    aria-label={`Delete testimonial by ${item.authorName}`}
                  >
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </section>
    </div>
  );
}
