import { useState } from 'react';
import { CheckCircle2, Search, Trash2, XCircle } from 'lucide-react';
import { useApp } from '../../contexts/AppContext';
import { adminDeleteBooking, adminUpdateBookingStatus } from '../../services/hostelService';
import type { BookingRecord, BookingStatusValue } from '../../types/hostel';

interface AdminBookingsTabProps {
  bookings: BookingRecord[];
  onRefresh: () => Promise<void>;
}

export function AdminBookingsTab({ bookings, onRefresh }: AdminBookingsTabProps) {
  const { rooms, refreshPublicData } = useApp();
  const [filter, setFilter] = useState<'all' | BookingStatusValue>('all');
  const [search, setSearch] = useState('');
  const [busyId, setBusyId] = useState<string | null>(null);
  const [noteById, setNoteById] = useState<Record<string, string>>({});

  const filtered = bookings.filter((b) => {
    if (filter !== 'all' && b.status !== filter) return false;
    if (search.trim()) {
      const q = search.trim().toLowerCase();
      return (
        b.bookingCode.toLowerCase().includes(q) ||
        b.studentName.toLowerCase().includes(q) ||
        b.mobile.includes(q) ||
        b.institution.toLowerCase().includes(q)
      );
    }
    return true;
  });

  const handleStatusChange = async (booking: BookingRecord, status: BookingStatusValue) => {
    setBusyId(booking.id);
    try {
      await adminUpdateBookingStatus(
        booking,
        status,
        noteById[booking.id] ?? booking.adminNote ?? '',
        rooms
      );
      await Promise.all([onRefresh(), refreshPublicData()]);
    } finally {
      setBusyId(null);
    }
  };

  const handleDelete = async (booking: BookingRecord) => {
    setBusyId(booking.id);
    try {
      await adminDeleteBooking(booking);
      await onRefresh();
    } finally {
      setBusyId(null);
    }
  };

  return (
    <div className="space-y-6">
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h2 className="text-xl font-bold text-[#0F2342]">Booking Applications</h2>
          <p className="text-sm text-slate-600">
            Review student applications. Bookings remain Pending until explicitly approved.
          </p>
        </div>

        <div className="relative w-full sm:w-64">
          <Search className="w-4 h-4 text-slate-400 absolute left-3 top-1/2 -translate-y-1/2" />
          <input
            type="text"
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            placeholder="Search ID, name, phone..."
            aria-label="Search bookings"
            className="w-full pl-9 pr-3 py-2 text-sm bg-white border border-slate-300 rounded-lg"
          />
        </div>
      </div>

      <div className="inline-flex flex-wrap items-center gap-1 p-1 bg-white border border-slate-200 rounded-lg">
        {(['all', 'pending', 'approved', 'rejected', 'completed'] as const).map((tab) => (
          <button
            key={tab}
            type="button"
            onClick={() => setFilter(tab)}
            className={`px-3 py-1.5 text-xs font-semibold rounded-md capitalize transition-colors ${
              filter === tab ? 'bg-[#0F2342] text-white' : 'text-slate-600 hover:text-[#0F2342]'
            }`}
          >
            {tab}
          </button>
        ))}
      </div>

      {filtered.length === 0 ? (
        <div className="bg-white border border-slate-200 rounded-xl p-10 text-center space-y-1">
          <p className="text-base font-semibold text-[#0F2342]">No booking records match this filter</p>
          <p className="text-sm text-slate-500">
            New student room booking applications will appear here automatically.
          </p>
        </div>
      ) : (
        <div className="bg-white border border-slate-200 rounded-xl overflow-x-auto">
          <table className="w-full text-left border-collapse text-sm">
            <thead>
              <tr className="border-b border-slate-200 bg-slate-50 text-xs font-semibold text-slate-600">
                <th className="py-3 px-4">Booking ID</th>
                <th className="py-3 px-4">Student & Institution</th>
                <th className="py-3 px-4">Phones</th>
                <th className="py-3 px-4">Room / Date</th>
                <th className="py-3 px-4">Status</th>
                <th className="py-3 px-4">Admin Note</th>
                <th className="py-3 px-4 text-right">Actions</th>
              </tr>
            </thead>
            <tbody className="divide-y divide-slate-100">
              {filtered.map((bk) => (
                <tr key={bk.id} className="hover:bg-slate-50/70 align-top">
                  <td className="py-3 px-4 font-mono-tabular font-bold text-[#0F2342] whitespace-nowrap">
                    {bk.bookingCode}
                  </td>
                  <td className="py-3 px-4">
                    <div className="font-semibold text-[#0F2342]">{bk.studentName}</div>
                    <div className="text-xs text-slate-500">{bk.institution}</div>
                  </td>
                  <td className="py-3 px-4 font-mono-tabular text-xs space-y-0.5">
                    <div>S: {bk.mobile}</div>
                    <div className="text-slate-500">G: {bk.guardianMobile}</div>
                  </td>
                  <td className="py-3 px-4 text-xs space-y-0.5">
                    <div className="font-medium text-slate-800">
                      {bk.roomType} ({bk.occupants})
                    </div>
                    <div className="font-mono-tabular text-slate-500">{bk.preferredDate}</div>
                  </td>
                  <td className="py-3 px-4">
                    <span
                      className={`text-xs font-semibold capitalize ${
                        bk.status === 'approved' || bk.status === 'completed'
                          ? 'text-emerald-700'
                          : bk.status === 'rejected'
                            ? 'text-rose-700'
                            : 'text-amber-700'
                      }`}
                    >
                      {bk.status}
                    </span>
                  </td>
                  <td className="py-3 px-4">
                    <input
                      type="text"
                      value={noteById[bk.id] ?? bk.adminNote ?? ''}
                      onChange={(e) => setNoteById({ ...noteById, [bk.id]: e.target.value })}
                      placeholder="Optional note"
                      className="w-36 px-2 py-1 text-xs border border-slate-300 rounded"
                    />
                  </td>
                  <td className="py-3 px-4 text-right whitespace-nowrap space-x-1.5">
                    <button
                      type="button"
                      disabled={busyId === bk.id || bk.status === 'approved'}
                      onClick={() => handleStatusChange(bk, 'approved')}
                      className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-emerald-800 bg-emerald-50 border border-emerald-200 rounded hover:bg-emerald-100 disabled:opacity-40"
                    >
                      <CheckCircle2 className="w-3.5 h-3.5" />
                      Approve
                    </button>
                    <button
                      type="button"
                      disabled={busyId === bk.id || bk.status === 'rejected'}
                      onClick={() => handleStatusChange(bk, 'rejected')}
                      className="inline-flex items-center gap-1 px-2.5 py-1 text-xs font-semibold text-rose-800 bg-rose-50 border border-rose-200 rounded hover:bg-rose-100 disabled:opacity-40"
                    >
                      <XCircle className="w-3.5 h-3.5" />
                      Reject
                    </button>
                    <button
                      type="button"
                      disabled={busyId === bk.id || bk.status === 'completed'}
                      onClick={() => handleStatusChange(bk, 'completed')}
                      className="inline-flex items-center px-2.5 py-1 text-xs font-semibold text-[#0F2342] border border-slate-300 rounded hover:bg-slate-100 disabled:opacity-40"
                    >
                      Complete
                    </button>
                    <button
                      type="button"
                      disabled={busyId === bk.id}
                      onClick={() => handleDelete(bk)}
                      aria-label={`Delete booking ${bk.bookingCode}`}
                      className="inline-flex items-center p-1 text-slate-500 hover:text-rose-700"
                    >
                      <Trash2 className="w-4 h-4" />
                    </button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      )}
    </div>
  );
}
