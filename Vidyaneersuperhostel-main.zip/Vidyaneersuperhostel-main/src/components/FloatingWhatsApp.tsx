import { MessageCircle } from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { formatWhatsAppUrl } from '../utils/validation';

export function FloatingWhatsApp() {
  const { settings, lang } = useApp();
  const primaryWa = settings.whatsappNumbers[0] || '01928949055';

  return (
    <a
      href={formatWhatsAppUrl(
        primaryWa,
        lang === 'bn'
          ? 'আসসালামু আলাইকুম, বিদ্যা নীড় সুপার হোস্টেলের রুম ও সিট বুকিং সম্পর্কে জানতে চাই।'
          : 'Hello, I would like to inquire about room availability at Bidya Neer Super Hostel.'
      )}
      target="_blank"
      rel="noopener noreferrer"
      aria-label={lang === 'bn' ? 'হোয়াটসঅ্যাপে যোগাযোগ করুন' : 'Chat on WhatsApp'}
      className="fixed bottom-5 right-5 z-30 inline-flex items-center justify-center w-12 h-12 rounded-full bg-[#15803D] hover:bg-[#166534] text-white shadow-lg transition-transform duration-150 hover:scale-105 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#D99B26]"
    >
      <MessageCircle className="w-6 h-6" aria-hidden="true" />
    </a>
  );
}
