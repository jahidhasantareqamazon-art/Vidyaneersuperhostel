import { Link } from 'react-router-dom';
import { MapPin, MessageCircle, Phone } from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { formatTelUrl, formatWhatsAppUrl } from '../utils/validation';

export function Footer() {
  const { lang, setLang, t, settings } = useApp();

  return (
    <footer className="bg-[#0F2342] text-white/90 border-t border-white/10">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-14">
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-10">
          {/* Brand Summary */}
          <div className="space-y-4">
            <h2 className="text-xl font-bold text-white font-display">
              {lang === 'bn' ? settings.hostelNameBn : settings.hostelName}
            </h2>
            <p className="text-sm text-slate-300 leading-relaxed max-w-xs">
              {t.footer.tagline}
            </p>
            <div className="pt-2">
              <div className="inline-flex items-center gap-1 p-1 bg-white/10 rounded-lg">
                <button
                  type="button"
                  onClick={() => setLang('bn')}
                  className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors ${
                    lang === 'bn' ? 'bg-[#D99B26] text-[#0F2342]' : 'text-slate-200 hover:text-white'
                  }`}
                >
                  বাংলা
                </button>
                <button
                  type="button"
                  onClick={() => setLang('en')}
                  className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors ${
                    lang === 'en' ? 'bg-[#D99B26] text-[#0F2342]' : 'text-slate-200 hover:text-white'
                  }`}
                >
                  English
                </button>
              </div>
            </div>
          </div>

          {/* Quick Links */}
          <div>
            <h3 className="text-sm font-semibold text-white mb-4 tracking-wide">
              {t.footer.quickLinks}
            </h3>
            <ul className="space-y-2.5 text-sm text-slate-300">
              <li>
                <Link to="/" className="hover:text-[#D99B26] transition-colors">
                  {t.nav.home}
                </Link>
              </li>
              <li>
                <Link to="/about" className="hover:text-[#D99B26] transition-colors">
                  {t.nav.about}
                </Link>
              </li>
              <li>
                <Link to="/rooms" className="hover:text-[#D99B26] transition-colors">
                  {t.nav.rooms}
                </Link>
              </li>
              <li>
                <Link to="/facilities" className="hover:text-[#D99B26] transition-colors">
                  {t.nav.facilities}
                </Link>
              </li>
            </ul>
          </div>

          {/* Explore */}
          <div>
            <h3 className="text-sm font-semibold text-white mb-4 tracking-wide">
              {t.footer.explore}
            </h3>
            <ul className="space-y-2.5 text-sm text-slate-300">
              <li>
                <Link to="/gallery" className="hover:text-[#D99B26] transition-colors">
                  {t.nav.gallery}
                </Link>
              </li>
              <li>
                <Link to="/booking" className="hover:text-[#D99B26] transition-colors">
                  {t.nav.bookRoom}
                </Link>
              </li>
              <li>
                <Link to="/contact" className="hover:text-[#D99B26] transition-colors">
                  {t.nav.contact}
                </Link>
              </li>
              <li>
                <Link to="/admin" className="hover:text-[#D99B26] transition-colors">
                  {t.nav.adminPortal}
                </Link>
              </li>
            </ul>
          </div>

          {/* Contact Info */}
          <div>
            <h3 className="text-sm font-semibold text-white mb-4 tracking-wide">
              {t.footer.directContact}
            </h3>
            <ul className="space-y-3 text-sm text-slate-300">
              {settings.phones.map((phone) => (
                <li key={phone} className="flex items-center gap-2.5">
                  <Phone className="w-4 h-4 text-[#D99B26] shrink-0" aria-hidden="true" />
                  <a
                    href={formatTelUrl(phone)}
                    className="font-mono-tabular hover:text-white transition-colors"
                  >
                    {phone}
                  </a>
                  <span aria-hidden="true" className="text-slate-500">·</span>
                  <a
                    href={formatWhatsAppUrl(phone)}
                    target="_blank"
                    rel="noopener noreferrer"
                    className="inline-flex items-center gap-1 text-xs text-[#D99B26] hover:underline"
                  >
                    <MessageCircle className="w-3.5 h-3.5" aria-hidden="true" />
                    WhatsApp
                  </a>
                </li>
              ))}
              <li className="flex items-start gap-2.5 pt-1">
                <MapPin className="w-4 h-4 text-[#D99B26] shrink-0 mt-0.5" aria-hidden="true" />
                <span>{lang === 'bn' ? settings.addressBn : settings.addressEn}</span>
              </li>
            </ul>
          </div>
        </div>

        <div className="mt-12 pt-6 border-t border-white/10 flex flex-col sm:flex-row items-center justify-between gap-4 text-xs text-slate-400">
          <p>
            © {new Date().getFullYear()} {settings.hostelName} ({settings.hostelNameBn}). {t.footer.rights}
          </p>
          <p>Narsingdi, Bangladesh</p>
        </div>
      </div>
    </footer>
  );
}
