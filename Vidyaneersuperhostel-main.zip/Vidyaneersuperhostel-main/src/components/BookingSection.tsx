import { useEffect, useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { AlertCircle, CheckCircle2, Clock, Search, ShieldCheck } from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { lookupBookingStatus, submitBooking } from '../services/hostelService';
import type { PublicBookingStatus } from '../types/hostel';
import {
  bookingFormSchema,
  validateRoomAvailabilityForBooking,
  type BookingFormInput,
} from '../utils/validation';

interface BookingSectionProps {
  preselectedRoomId?: string;
  hideHeader?: boolean;
}

const HISTORY_KEY = 'bidyanidhi_booking_history';

export function BookingSection({ preselectedRoomId, hideHeader = false }: BookingSectionProps) {
  const { lang, t, rooms, seededInFirestore } = useApp();
  const [submitError, setSubmitError] = useState<string | null>(null);
  const [confirmedResult, setConfirmedResult] = useState<PublicBookingStatus | null>(null);

  const [lookupCode, setLookupCode] = useState('');
  const [lookupLoading, setLookupLoading] = useState(false);
  const [lookupResult, setLookupResult] = useState<PublicBookingStatus | null>(null);
  const [lookupError, setLookupError] = useState<string | null>(null);

  const [recentHistory, setRecentHistory] = useState<PublicBookingStatus[]>(() => {
    try {
      const raw = localStorage.getItem(HISTORY_KEY);
      return raw ? (JSON.parse(raw) as PublicBookingStatus[]) : [];
    } catch {
      return [];
    }
  });

  const defaultRoom =
    rooms.find((r) => r.id === preselectedRoomId) ||
    rooms.find((r) => r.availableSeats > 0) ||
    rooms[0];

  const {
    register,
    handleSubmit,
    setValue,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<BookingFormInput>({
    resolver: zodResolver(bookingFormSchema) as never,
    defaultValues: {
      studentName: '',
      mobile: '',
      guardianMobile: '',
      institution: '',
      roomId: defaultRoom?.id || 'room-single',
      occupants: 1,
      preferredDate: new Date(Date.now() + 7 * 86400_000).toISOString().slice(0, 10),
      message: '',
    },
  });

  useEffect(() => {
    if (preselectedRoomId) {
      setValue('roomId', preselectedRoomId);
    }
  }, [preselectedRoomId, setValue]);

  const onSubmit = async (data: BookingFormInput) => {
    setSubmitError(null);
    const chosenRoom = rooms.find((r) => r.id === data.roomId);
    const availCheck = validateRoomAvailabilityForBooking(chosenRoom, data.occupants);

    if (!availCheck.ok || !chosenRoom) {
      if (availCheck.reason === 'insufficient_seats') {
        setSubmitError(
          lang === 'bn'
            ? `দুঃখিত, এই রুমে কেবল ${chosenRoom?.availableSeats ?? 0}টি সিট ফাঁকা রয়েছে।`
            : `Sorry, only ${chosenRoom?.availableSeats ?? 0} seat(s) are available in this room.`
        );
      } else {
        setSubmitError(
          lang === 'bn'
            ? 'নির্বাচিত রুমটি বর্তমানে বুকিংয়ের জন্য উপলব্ধ নয়।'
            : 'The selected room is currently unavailable for booking.'
        );
      }
      return;
    }

    try {
      const result = await submitBooking(data, chosenRoom, seededInFirestore);
      setConfirmedResult(result);
      setLookupCode(result.bookingCode);
      setLookupResult(result);

      const updatedHistory = [result, ...recentHistory.filter((h) => h.bookingCode !== result.bookingCode)].slice(0, 5);
      setRecentHistory(updatedHistory);
      try {
        localStorage.setItem(HISTORY_KEY, JSON.stringify(updatedHistory));
      } catch {
        // ignore storage quota errors
      }
      reset({
        studentName: '',
        mobile: '',
        guardianMobile: '',
        institution: '',
        roomId: chosenRoom.id,
        occupants: 1,
        preferredDate: data.preferredDate,
        message: '',
      });
    } catch (err) {
      const msg = err instanceof Error ? err.message : '';
      if (msg === 'DUPLICATE_BOOKING') {
        setSubmitError(
          lang === 'bn'
            ? 'এই মোবাইল নম্বর ও তারিখের জন্য একটি আবেদন ইতিমধ্যেই জমা হয়েছে।'
            : 'A booking request with this mobile number and move-in date was already submitted recently.'
        );
      } else {
        setSubmitError(
          lang === 'bn'
            ? 'আবেদন জমা দেওয়ার সময় ত্রুটি হয়েছে। অনুগ্রহ করে তথ্য যাচাই করে পুনরায় চেষ্টা করুন।'
            : 'Unable to submit booking request. Please verify your details and try again.'
        );
      }
    }
  };

  const handleLookup = async (codeOverride?: string) => {
    const queryCode = (codeOverride ?? lookupCode).trim().toUpperCase();
    if (!queryCode) return;
    setLookupLoading(true);
    setLookupError(null);
    setLookupResult(null);
    try {
      const found = await lookupBookingStatus(queryCode);
      if (!found) {
        setLookupError(t.booking.lookupNotFound);
      } else {
        setLookupResult(found);
      }
    } finally {
      setLookupLoading(false);
    }
  };

  const getStatusLabel = (status: PublicBookingStatus['status']) =>
    t.booking.statusLabels[status];

  return (
    <section id="booking" className={hideHeader ? 'py-14 bg-[#F6F7FA]' : 'py-20 bg-[#F6F7FA]'}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {!hideHeader && (
          <div className="max-w-2xl mb-12">
            <p className="text-xs font-semibold tracking-wider text-[#B67E16] mb-2">
              {t.booking.kicker}
            </p>
            <h2 className="text-3xl sm:text-4xl font-bold text-[#0F2342] [text-wrap:balance]">
              {t.booking.title}
            </h2>
            <p className="mt-3 text-base text-slate-600 leading-relaxed">
              {t.booking.subtitle}
            </p>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-start">
          {/* Booking Form */}
          <div className="lg:col-span-7 bg-white border border-slate-200 rounded-xl p-6 sm:p-8">
            <div className="mb-6 p-4 rounded-lg bg-amber-50 border border-amber-200/80 flex items-start gap-3">
              <Clock className="w-5 h-5 text-amber-700 shrink-0 mt-0.5" aria-hidden="true" />
              <p className="text-sm text-amber-900 leading-relaxed">{t.booking.noticePending}</p>
            </div>

            {confirmedResult && (
              <div
                role="status"
                aria-live="polite"
                className="mb-6 p-5 rounded-xl bg-emerald-50 border border-emerald-200 space-y-3"
              >
                <div className="flex items-start gap-3">
                  <CheckCircle2 className="w-6 h-6 text-emerald-700 shrink-0 mt-0.5" aria-hidden="true" />
                  <div>
                    <h3 className="text-base font-bold text-emerald-950">
                      {t.booking.successTitle}
                    </h3>
                    <p className="text-sm text-emerald-800 mt-0.5">
                      {t.booking.successSubtitle}
                    </p>
                  </div>
                </div>
                <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 border-t border-emerald-200/70 text-sm">
                  <div>
                    <span className="text-xs text-emerald-700 block">{t.booking.bookingIdLabel}</span>
                    <span className="font-mono-tabular font-bold text-base text-emerald-950">
                      {confirmedResult.bookingCode}
                    </span>
                  </div>
                  <div>
                    <span className="text-xs text-emerald-700 block">{t.booking.currentStatusLabel}</span>
                    <span className="font-semibold text-amber-800">
                      {getStatusLabel(confirmedResult.status)}
                    </span>
                  </div>
                </div>
              </div>
            )}

            {submitError && (
              <div
                role="alert"
                className="mb-6 p-4 rounded-lg bg-rose-50 border border-rose-200 flex items-start gap-3 text-rose-900 text-sm"
              >
                <AlertCircle className="w-5 h-5 text-rose-700 shrink-0 mt-0.5" aria-hidden="true" />
                <span>{submitError}</span>
              </div>
            )}

            <form onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <label htmlFor="bk-studentName" className="block text-sm font-medium text-[#0F2342] mb-1.5">
                    {t.booking.studentName} *
                  </label>
                  <input
                    id="bk-studentName"
                    type="text"
                    {...register('studentName')}
                    className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-[#0F2342] focus:ring-2 focus:ring-[#0F2342]/10"
                  />
                  {errors.studentName && (
                    <p className="mt-1 text-xs text-rose-600">{errors.studentName.message}</p>
                  )}
                </div>

                <div>
                  <label htmlFor="bk-institution" className="block text-sm font-medium text-[#0F2342] mb-1.5">
                    {t.booking.institution} *
                  </label>
                  <input
                    id="bk-institution"
                    type="text"
                    placeholder={lang === 'bn' ? 'যেমন: নরসিংদী সরকারি কলেজ' : 'e.g. Narsingdi Govt. College'}
                    {...register('institution')}
                    className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-[#0F2342] focus:ring-2 focus:ring-[#0F2342]/10"
                  />
                  {errors.institution && (
                    <p className="mt-1 text-xs text-rose-600">{errors.institution.message}</p>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <label htmlFor="bk-mobile" className="block text-sm font-medium text-[#0F2342] mb-1.5">
                    {t.booking.mobile} *
                  </label>
                  <input
                    id="bk-mobile"
                    type="tel"
                    placeholder="01XXXXXXXXX"
                    {...register('mobile')}
                    className="w-full px-3.5 py-2.5 text-sm font-mono-tabular border border-slate-300 rounded-lg focus:outline-none focus:border-[#0F2342] focus:ring-2 focus:ring-[#0F2342]/10"
                  />
                  {errors.mobile && (
                    <p className="mt-1 text-xs text-rose-600">{errors.mobile.message}</p>
                  )}
                </div>

                <div>
                  <label htmlFor="bk-guardianMobile" className="block text-sm font-medium text-[#0F2342] mb-1.5">
                    {t.booking.guardianMobile} *
                  </label>
                  <input
                    id="bk-guardianMobile"
                    type="tel"
                    placeholder="01XXXXXXXXX"
                    {...register('guardianMobile')}
                    className="w-full px-3.5 py-2.5 text-sm font-mono-tabular border border-slate-300 rounded-lg focus:outline-none focus:border-[#0F2342] focus:ring-2 focus:ring-[#0F2342]/10"
                  />
                  {errors.guardianMobile && (
                    <p className="mt-1 text-xs text-rose-600">{errors.guardianMobile.message}</p>
                  )}
                </div>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-3 gap-5">
                <div className="sm:col-span-1">
                  <label htmlFor="bk-roomId" className="block text-sm font-medium text-[#0F2342] mb-1.5">
                    {t.booking.roomType} *
                  </label>
                  <select
                    id="bk-roomId"
                    {...register('roomId')}
                    className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-lg bg-white focus:outline-none focus:border-[#0F2342] focus:ring-2 focus:ring-[#0F2342]/10"
                  >
                    {rooms.map((r) => (
                      <option key={r.id} value={r.id}>
                        {lang === 'bn' ? r.titleBn : r.titleEn} ({r.availableSeats} {lang === 'bn' ? 'আসন' : 'seats'})
                      </option>
                    ))}
                  </select>
                  {errors.roomId && (
                    <p className="mt-1 text-xs text-rose-600">{errors.roomId.message}</p>
                  )}
                </div>

                <div>
                  <label htmlFor="bk-occupants" className="block text-sm font-medium text-[#0F2342] mb-1.5">
                    {t.booking.occupants} *
                  </label>
                  <input
                    id="bk-occupants"
                    type="number"
                    min={1}
                    max={10}
                    {...register('occupants')}
                    className="w-full px-3.5 py-2.5 text-sm font-mono-tabular border border-slate-300 rounded-lg focus:outline-none focus:border-[#0F2342] focus:ring-2 focus:ring-[#0F2342]/10"
                  />
                  {errors.occupants && (
                    <p className="mt-1 text-xs text-rose-600">{errors.occupants.message}</p>
                  )}
                </div>

                <div>
                  <label htmlFor="bk-preferredDate" className="block text-sm font-medium text-[#0F2342] mb-1.5">
                    {t.booking.preferredDate} *
                  </label>
                  <input
                    id="bk-preferredDate"
                    type="date"
                    {...register('preferredDate')}
                    className="w-full px-3.5 py-2.5 text-sm font-mono-tabular border border-slate-300 rounded-lg focus:outline-none focus:border-[#0F2342] focus:ring-2 focus:ring-[#0F2342]/10"
                  />
                  {errors.preferredDate && (
                    <p className="mt-1 text-xs text-rose-600">{errors.preferredDate.message}</p>
                  )}
                </div>
              </div>

              <div>
                <label htmlFor="bk-message" className="block text-sm font-medium text-[#0F2342] mb-1.5">
                  {t.booking.message}
                </label>
                <textarea
                  id="bk-message"
                  rows={3}
                  {...register('message')}
                  className="w-full px-3.5 py-2.5 text-sm border border-slate-300 rounded-lg focus:outline-none focus:border-[#0F2342] focus:ring-2 focus:ring-[#0F2342]/10"
                />
                {errors.message && (
                  <p className="mt-1 text-xs text-rose-600">{errors.message.message}</p>
                )}
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="w-full sm:w-auto inline-flex items-center justify-center px-6 py-3 text-sm font-semibold text-white bg-[#0F2342] hover:bg-[#193766] rounded-lg transition-colors duration-150 disabled:opacity-60"
              >
                {isSubmitting ? t.booking.submitting : t.booking.submitBtn}
              </button>
            </form>
          </div>

          {/* Booking Status Lookup & Local History */}
          <div className="lg:col-span-5 space-y-6">
            <div className="bg-white border border-slate-200 rounded-xl p-6 sm:p-8 space-y-4">
              <div className="flex items-center gap-2.5 text-[#0F2342]">
                <ShieldCheck className="w-5 h-5 text-[#D99B26]" aria-hidden="true" />
                <h3 className="text-lg font-bold">{t.booking.lookupTitle}</h3>
              </div>
              <p className="text-sm text-slate-600 leading-relaxed">{t.booking.lookupSubtitle}</p>

              <form
                onSubmit={(e) => {
                  e.preventDefault();
                  handleLookup();
                }}
                className="flex flex-col sm:flex-row gap-2.5"
              >
                <label htmlFor="lookup-code" className="sr-only">
                  {t.booking.bookingIdLabel}
                </label>
                <input
                  id="lookup-code"
                  type="text"
                  value={lookupCode}
                  onChange={(e) => setLookupCode(e.target.value)}
                  placeholder={t.booking.lookupPlaceholder}
                  className="flex-1 px-3.5 py-2.5 text-sm font-mono-tabular uppercase border border-slate-300 rounded-lg focus:outline-none focus:border-[#0F2342]"
                />
                <button
                  type="submit"
                  disabled={lookupLoading}
                  className="inline-flex items-center justify-center gap-2 px-4 py-2.5 text-sm font-semibold text-[#0F2342] bg-[#D99B26] hover:bg-[#c58a1c] rounded-lg transition-colors whitespace-nowrap"
                >
                  <Search className="w-4 h-4" aria-hidden="true" />
                  {t.booking.lookupBtn}
                </button>
              </form>

              {lookupError && (
                <p className="text-sm text-rose-700 bg-rose-50 border border-rose-200 rounded-lg p-3">
                  {lookupError}
                </p>
              )}

              {lookupResult && (
                <div className="p-4 rounded-lg bg-slate-50 border border-slate-200 space-y-2 text-sm">
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-slate-500">{t.booking.bookingIdLabel}</span>
                    <span className="font-mono-tabular font-bold text-[#0F2342]">
                      {lookupResult.bookingCode}
                    </span>
                  </div>
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-slate-500">{t.booking.roomLabel}</span>
                    <span className="font-medium text-slate-800">{lookupResult.roomType}</span>
                  </div>
                  <div className="flex items-center justify-between gap-2">
                    <span className="text-slate-500">{t.booking.preferredDate}</span>
                    <span className="font-mono-tabular text-slate-800">{lookupResult.preferredDate}</span>
                  </div>
                  <div className="flex items-center justify-between gap-2 pt-2 border-t border-slate-200">
                    <span className="text-slate-500">{t.booking.currentStatusLabel}</span>
                    <span
                      className={`font-semibold ${
                        lookupResult.status === 'approved' || lookupResult.status === 'completed'
                          ? 'text-emerald-700'
                          : lookupResult.status === 'rejected'
                            ? 'text-rose-700'
                            : 'text-amber-700'
                      }`}
                    >
                      {getStatusLabel(lookupResult.status)}
                    </span>
                  </div>
                </div>
              )}
            </div>

            {recentHistory.length > 0 && (
              <div className="bg-white border border-slate-200 rounded-xl p-6 space-y-3">
                <h4 className="text-sm font-bold text-[#0F2342]">
                  {lang === 'bn' ? 'আপনার সাম্প্রতিক আবেদনসমূহ' : 'Your Recent Submissions'}
                </h4>
                <ul className="divide-y divide-slate-100 text-sm">
                  {recentHistory.map((item) => (
                    <li key={item.bookingCode} className="py-2.5 flex items-center justify-between gap-3">
                      <div>
                        <button
                          type="button"
                          onClick={() => {
                            setLookupCode(item.bookingCode);
                            handleLookup(item.bookingCode);
                          }}
                          className="font-mono-tabular font-semibold text-[#0F2342] hover:underline"
                        >
                          {item.bookingCode}
                        </button>
                        <p className="text-xs text-slate-500">{item.roomType}</p>
                      </div>
                      <span className="text-xs font-medium text-slate-600">
                        {item.preferredDate}
                      </span>
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </div>
        </div>
      </div>
    </section>
  );
}
