import { useState } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X } from 'lucide-react';
import { useApp } from '../contexts/AppContext';

export function Navbar() {
  const { lang, setLang, t, settings } = useApp();
  const location = useLocation();
  const [mobileOpen, setMobileOpen] = useState(false);

  const navItems = [
    { to: '/', label: t.nav.home },
    { to: '/about', label: t.nav.about },
    { to: '/rooms', label: t.nav.rooms },
    { to: '/facilities', label: t.nav.facilities },
    { to: '/contact', label: t.nav.contact },
  ];

  const isActive = (to: string) =>
    to === '/' ? location.pathname === '/' : location.pathname.startsWith(to);

  return (
    <header className="sticky top-0 z-40 bg-white/95 backdrop-blur-md border-b border-slate-200/80">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 h-16 flex items-center justify-between gap-8">
        {/* Zone 1: Single-line Brand Wordmark */}
        <Link
          to="/"
          className="text-lg sm:text-xl font-bold tracking-tight text-[#0F2342] whitespace-nowrap shrink-0 font-display focus-visible:outline-2 focus-visible:outline-offset-4 focus-visible:outline-[#D99B26]"
        >
          {lang === 'bn' ? settings.hostelNameBn : settings.hostelName}
        </Link>

        {/* Zone 2: 5 concise single-line navigation links */}
        <nav aria-label="Primary Navigation" className="hidden lg:flex items-center gap-7">
          {navItems.map((item) => (
            <Link
              key={item.to}
              to={item.to}
              className={`text-sm font-medium whitespace-nowrap shrink-0 transition-colors duration-150 py-1 border-b-2 ${
                isActive(item.to)
                  ? 'text-[#0F2342] border-[#D99B26]'
                  : 'text-slate-600 border-transparent hover:text-[#0F2342] hover:border-slate-300'
              }`}
            >
              {item.label}
            </Link>
          ))}
        </nav>

        {/* Zone 3: 1 primary action on desktop, menu toggle on mobile */}
        <div className="flex items-center gap-3 shrink-0">
          <Link
            to="/booking"
            className="hidden sm:inline-flex items-center justify-center px-5 py-2.5 text-sm font-semibold text-[#0F2342] bg-[#D99B26] hover:bg-[#c58a1c] rounded-lg transition-colors duration-150 whitespace-nowrap shrink-0 focus-visible:outline-2 focus-visible:outline-offset-2 focus-visible:outline-[#0F2342]"
          >
            {t.nav.bookRoom}
          </Link>

          <button
            type="button"
            onClick={() => setMobileOpen((prev) => !prev)}
            aria-label={mobileOpen ? 'Close navigation menu' : 'Open navigation menu'}
            aria-expanded={mobileOpen}
            className="lg:hidden inline-flex items-center justify-center w-11 h-11 rounded-lg border border-slate-200 text-[#0F2342] hover:bg-slate-100 transition-colors"
          >
            {mobileOpen ? <X className="w-5 h-5" /> : <Menu className="w-5 h-5" />}
          </button>
        </div>
      </div>

      {/* Mobile Drawer */}
      {mobileOpen && (
        <div className="lg:hidden bg-white border-b border-slate-200 px-4 py-4 space-y-2">
          <nav aria-label="Mobile Navigation" className="flex flex-col space-y-1">
            {[...navItems, { to: '/gallery', label: t.nav.gallery }].map((item) => (
              <Link
                key={item.to}
                to={item.to}
                onClick={() => setMobileOpen(false)}
                className={`px-3 py-2.5 rounded-lg text-sm font-medium transition-colors ${
                  isActive(item.to)
                    ? 'bg-[#0F2342]/5 text-[#0F2342] font-semibold'
                    : 'text-slate-700 hover:bg-slate-50'
                }`}
              >
                {item.label}
              </Link>
            ))}
          </nav>

          <div className="pt-3 border-t border-slate-100 flex items-center justify-between gap-3">
            <div className="flex items-center gap-1 p-1 bg-slate-100 rounded-lg">
              <button
                type="button"
                onClick={() => setLang('bn')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                  lang === 'bn' ? 'bg-white text-[#0F2342] shadow-sm' : 'text-slate-600'
                }`}
              >
                বাংলা
              </button>
              <button
                type="button"
                onClick={() => setLang('en')}
                className={`px-3 py-1.5 text-xs font-semibold rounded-md transition-colors ${
                  lang === 'en' ? 'bg-white text-[#0F2342] shadow-sm' : 'text-slate-600'
                }`}
              >
                English
              </button>
            </div>

            <Link
              to="/booking"
              onClick={() => setMobileOpen(false)}
              className="inline-flex items-center justify-center px-4 py-2.5 text-sm font-semibold text-[#0F2342] bg-[#D99B26] rounded-lg whitespace-nowrap"
            >
              {t.nav.bookRoom}
            </Link>
          </div>
        </div>
      )}
    </header>
  );
}
