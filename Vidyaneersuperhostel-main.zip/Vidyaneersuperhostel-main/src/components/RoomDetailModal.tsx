import { X } from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import type { Room, RoomImage } from '../types/hostel';
import { SafeImage } from './SafeImage';

interface RoomDetailModalProps {
  room: Room | null;
  images: RoomImage[];
  onClose: () => void;
  onBook: (room: Room) => void;
}

export function RoomDetailModal({ room, images, onClose, onBook }: RoomDetailModalProps) {
  const { lang, t } = useApp();

  if (!room) return null;

  const title = lang === 'bn' ? room.titleBn : room.titleEn;
  const description = lang === 'bn' ? room.descriptionBn : room.descriptionEn;
  const facilities = lang === 'bn' ? room.facilitiesBn : room.facilitiesEn;
  const relatedImages = images.filter((img) => img.roomId === room.id);

  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="room-modal-title"
      className="fixed inset-0 z-50 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center p-4"
      onClick={onClose}
    >
      <div
        className="bg-white rounded-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto border border-slate-200 shadow-xl"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="sticky top-0 bg-white/95 backdrop-blur-sm px-6 py-4 border-b border-slate-200 flex items-center justify-between gap-4">
          <h3 id="room-modal-title" className="text-xl font-bold text-[#0F2342]">
            {title}
          </h3>
          <button
            type="button"
            onClick={onClose}
            aria-label={lang === 'bn' ? 'বন্ধ করুন' : 'Close dialog'}
            className="w-10 h-10 inline-flex items-center justify-center rounded-lg border border-slate-200 text-slate-600 hover:bg-slate-100"
          >
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6 space-y-6">
          <div className="aspect-[16/10] rounded-lg overflow-hidden bg-slate-100">
            <SafeImage src={room.primaryImage} alt={title} className="w-full h-full object-cover" />
          </div>

          {relatedImages.length > 0 && (
            <div className="grid grid-cols-2 sm:grid-cols-3 gap-3">
              {relatedImages.map((img) => (
                <div key={img.id} className="aspect-[4/3] rounded-lg overflow-hidden bg-slate-100">
                  <SafeImage
                    src={img.imageUrl}
                    alt={(lang === 'bn' ? img.captionBn : img.captionEn) || title}
                    className="w-full h-full object-cover"
                  />
                </div>
              ))}
            </div>
          )}

          <div className="flex flex-wrap items-center gap-x-3 gap-y-1 text-sm text-slate-600">
            <span className="font-semibold text-[#0F2342]">
              {t.rooms.statusLabels[room.availabilityStatus]}
            </span>
            <span aria-hidden="true">·</span>
            <span className="tabular-nums">
              {t.rooms.capacityLabel}: {room.capacity}
            </span>
            <span aria-hidden="true">·</span>
            <span className="tabular-nums">
              {t.rooms.seatsLabel}: {room.availableSeats}
            </span>
          </div>

          <p className="text-sm sm:text-base text-slate-700 leading-relaxed">{description}</p>

          <div>
            <h4 className="text-sm font-bold text-[#0F2342] mb-2.5">
              {lang === 'bn' ? 'রুমের সুবিধাসমূহ' : 'Room Facilities'}
            </h4>
            <ul className="grid grid-cols-1 sm:grid-cols-2 gap-2 text-sm text-slate-700">
              {facilities.map((item, idx) => (
                <li key={idx} className="flex items-start gap-2">
                  <span className="text-[#D99B26] font-bold" aria-hidden="true">•</span>
                  <span>{item}</span>
                </li>
              ))}
            </ul>
          </div>

          <div className="pt-4 border-t border-slate-200 flex flex-col sm:flex-row sm:items-center justify-between gap-4">
            <div>
              <span className="text-xs text-slate-500 block">{t.rooms.monthlyRentLabel}</span>
              {room.priceConfirmed && room.monthlyRent !== null ? (
                <span className="text-xl font-bold text-[#0F2342] tabular-nums">
                  ৳{room.monthlyRent.toLocaleString()} {t.rooms.perMonth}
                </span>
              ) : (
                <span className="text-base font-semibold text-[#0F2342]">
                  {lang === 'bn' ? room.pricePlaceholderBn : room.pricePlaceholderEn}
                </span>
              )}
            </div>

            <button
              type="button"
              disabled={
                room.availabilityStatus === 'full' ||
                room.availabilityStatus === 'maintenance' ||
                room.availableSeats <= 0
              }
              onClick={() => {
                onClose();
                onBook(room);
              }}
              className="inline-flex items-center justify-center px-6 py-3 text-sm font-semibold text-white bg-[#0F2342] hover:bg-[#193766] rounded-lg transition-colors disabled:bg-slate-200 disabled:text-slate-500"
            >
              {t.rooms.bookThisRoom}
            </button>
          </div>
        </div>
      </div>
    </div>
  );
}
