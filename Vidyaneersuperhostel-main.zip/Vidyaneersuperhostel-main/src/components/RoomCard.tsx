import { CheckCircle2, Clock, Ban, Wrench, Users } from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import type { Room } from '../types/hostel';
import { SafeImage } from './SafeImage';

interface RoomCardProps {
  room: Room;
  onBookRoom: (room: Room) => void;
  onViewDetails?: (room: Room) => void;
}

export function RoomCard({ room, onBookRoom, onViewDetails }: RoomCardProps) {
  const { lang, t } = useApp();

  const title = lang === 'bn' ? room.titleBn : room.titleEn;
  const description = lang === 'bn' ? room.descriptionBn : room.descriptionEn;
  const facilities = lang === 'bn' ? room.facilitiesBn : room.facilitiesEn;
  const isAvailable =
    room.availabilityStatus !== 'full' &&
    room.availabilityStatus !== 'maintenance' &&
    room.availableSeats > 0;

  const statusMeta = {
    available: {
      label: t.rooms.statusLabels.available,
      color: 'text-emerald-700',
      Icon: CheckCircle2,
    },
    limited: {
      label: t.rooms.statusLabels.limited,
      color: 'text-amber-700',
      Icon: Clock,
    },
    full: {
      label: t.rooms.statusLabels.full,
      color: 'text-rose-700',
      Icon: Ban,
    },
    maintenance: {
      label: t.rooms.statusLabels.maintenance,
      color: 'text-slate-600',
      Icon: Wrench,
    },
  }[room.availabilityStatus];

  const StatusIcon = statusMeta.Icon;

  return (
    <article className="bg-white border border-slate-200 rounded-xl overflow-hidden flex flex-col justify-between transition-transform duration-200 hover:-translate-y-0.5">
      <div>
        <div className="aspect-[4/3] w-full overflow-hidden bg-slate-100">
          <SafeImage
            src={room.primaryImage}
            alt={title}
            className="w-full h-full object-cover"
          />
        </div>

        <div className="p-6 space-y-4">
          {/* Unboxed inline metadata row (Zero-Pill Discipline) */}
          <div className="flex flex-wrap items-center gap-x-2 gap-y-1 text-xs font-medium text-slate-500">
            <span className={`inline-flex items-center gap-1 font-semibold ${statusMeta.color}`}>
              <StatusIcon className="w-3.5 h-3.5" aria-hidden="true" />
              {statusMeta.label}
            </span>
            <span aria-hidden="true">·</span>
            <span className="inline-flex items-center gap-1 tabular-nums">
              <Users className="w-3.5 h-3.5 text-slate-400" aria-hidden="true" />
              {t.rooms.capacityLabel}: {room.capacity}
            </span>
            <span aria-hidden="true">·</span>
            <span className="tabular-nums text-[#0F2342] font-semibold">
              {t.rooms.seatsLabel}: {room.availableSeats}
            </span>
          </div>

          <div>
            <h3 className="text-xl font-bold text-[#0F2342] leading-snug">{title}</h3>
            <p className="mt-2 text-sm text-slate-600 leading-relaxed line-clamp-3">
              {description}
            </p>
          </div>

          <ul className="space-y-1.5 pt-2 border-t border-slate-100 text-sm text-slate-700">
            {facilities.slice(0, 4).map((fac, idx) => (
              <li key={idx} className="flex items-start gap-2">
                <span className="text-[#D99B26] font-bold leading-5" aria-hidden="true">•</span>
                <span>{fac}</span>
              </li>
            ))}
          </ul>
        </div>
      </div>

      <div className="px-6 pb-6 pt-4 border-t border-slate-100 space-y-4">
        <div className="flex items-baseline justify-between gap-2">
          <span className="text-xs font-medium text-slate-500">{t.rooms.monthlyRentLabel}</span>
          {room.priceConfirmed && room.monthlyRent !== null ? (
            <span className="text-lg font-bold text-[#0F2342] tabular-nums">
              ৳{room.monthlyRent.toLocaleString()}
              <span className="text-xs font-normal text-slate-500 ml-1">{t.rooms.perMonth}</span>
            </span>
          ) : (
            <span className="text-sm font-semibold text-[#0F2342]">
              {lang === 'bn' ? room.pricePlaceholderBn : room.pricePlaceholderEn}
            </span>
          )}
        </div>

        <div className="flex items-center gap-2.5">
          <button
            type="button"
            disabled={!isAvailable}
            onClick={() => onBookRoom(room)}
            className="flex-1 inline-flex items-center justify-center px-4 py-2.5 text-sm font-semibold rounded-lg transition-colors duration-150 whitespace-nowrap bg-[#0F2342] text-white hover:bg-[#193766] disabled:bg-slate-200 disabled:text-slate-500 disabled:cursor-not-allowed"
          >
            {t.rooms.bookThisRoom}
          </button>
          {onViewDetails && (
            <button
              type="button"
              onClick={() => onViewDetails(room)}
              className="inline-flex items-center justify-center px-3.5 py-2.5 text-sm font-medium rounded-lg border border-slate-200 text-[#0F2342] hover:bg-slate-50 transition-colors whitespace-nowrap"
            >
              {t.rooms.viewDetails}
            </button>
          )}
        </div>
      </div>
    </article>
  );
}
