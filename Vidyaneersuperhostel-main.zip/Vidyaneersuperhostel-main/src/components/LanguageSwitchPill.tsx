import { useApp } from '../contexts/AppContext';

export function LanguageSwitchPill() {
  const { lang, setLang } = useApp();
  return (
    <div className="inline-flex items-center gap-1 p-1 bg-white/10 rounded-lg shrink-0">
      <button
        type="button"
        onClick={() => setLang('bn')}
        className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors ${
          lang === 'bn' ? 'bg-[#D99B26] text-[#0F2342]' : 'text-slate-200 hover:text-white'
        }`}
      >
        বাংলা
      </button>
      <button
        type="button"
        onClick={() => setLang('en')}
        className={`px-3 py-1 text-xs font-semibold rounded-md transition-colors ${
          lang === 'en' ? 'bg-[#D99B26] text-[#0F2342]' : 'text-slate-200 hover:text-white'
        }`}
      >
        English
      </button>
    </div>
  );
}
