import { useState } from 'react';
import { useForm } from 'react-hook-form';
import { zodResolver } from '@hookform/resolvers/zod';
import { CheckCircle2, ExternalLink, MapPin, MessageCircle, Phone } from 'lucide-react';
import { useApp } from '../contexts/AppContext';
import { submitContactInquiry } from '../services/hostelService';
import {
  formatTelUrl,
  formatWhatsAppUrl,
  getNarsingdiMapsSearchUrl,
  inquiryFormSchema,
  type InquiryFormInput,
} from '../utils/validation';

export function ContactSection({ hideHeader = false }: { hideHeader?: boolean }) {
  const { lang, t, settings } = useApp();
  const [sent, setSent] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);

  const {
    register,
    handleSubmit,
    reset,
    formState: { errors, isSubmitting },
  } = useForm<InquiryFormInput>({
    resolver: zodResolver(inquiryFormSchema) as never,
    defaultValues: {
      senderName: '',
      phone: '',
      subject: '',
      message: '',
    },
  });

  const onSubmit = async (data: InquiryFormInput) => {
    setErrorMsg(null);
    setSent(false);
    try {
      await submitContactInquiry(data);
      setSent(true);
      reset();
    } catch {
      setErrorMsg(
        lang === 'bn'
          ? 'বার্তা পাঠানো সম্ভব হয়নি। সরাসরি কল অথবা হোয়াটসঅ্যাপে যোগাযোগ করুন।'
          : 'Could not send message. Please reach us directly by phone or WhatsApp.'
      );
    }
  };

  return (
    <section id="contact" className={hideHeader ? 'py-14 bg-white' : 'py-20 bg-white border-t border-slate-200/80'}>
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        {!hideHeader && (
          <div className="max-w-2xl mb-12">
            <p className="text-xs font-semibold tracking-wider text-[#B67E16] mb-2">
              {t.contact.kicker}
            </p>
            <h2 className="text-3xl sm:text-4xl font-bold text-[#0F2342] [text-wrap:balance]">
              {t.contact.title}
            </h2>
            <p className="mt-3 text-base text-slate-600 leading-relaxed">{t.contact.subtitle}</p>
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8 items-stretch">
          {/* Direct Contact Channels & Location */}
          <div className="lg:col-span-5 flex flex-col justify-between bg-[#0F2342] text-white rounded-xl p-6 sm:p-8 space-y-8">
            <div className="space-y-6">
              <div>
                <h3 className="text-lg font-bold text-white mb-4">
                  {lang === 'bn' ? 'সরাসরি ফোন ও হোয়াটসঅ্যাপ' : 'Direct Phone & WhatsApp'}
                </h3>
                <div className="space-y-4">
                  {settings.phones.map((phone, idx) => (
                    <div
                      key={phone}
                      className="p-4 rounded-lg bg-white/5 border border-white/10 space-y-3"
                    >
                      <div className="flex items-center justify-between gap-2">
                        <span className="text-xs text-slate-300">
                          {idx === 0
                            ? lang === 'bn'
                              ? 'প্রধান যোগাযোগ নম্বর'
                              : 'Primary Contact'
                            : lang === 'bn'
                              ? 'বিকল্প যোগাযোগ নম্বর'
                              : 'Secondary Contact'}
                        </span>
                        <span className="font-mono-tabular text-base font-bold text-[#D99B26]">
                          {phone}
                        </span>
                      </div>
                      <div className="flex items-center gap-2.5">
                        <a
                          href={formatTelUrl(phone)}
                          className="flex-1 inline-flex items-center justify-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-lg bg-white text-[#0F2342] hover:bg-slate-100 transition-colors"
                        >
                          <Phone className="w-3.5 h-3.5" aria-hidden="true" />
                          {t.contact.callNow}
                        </a>
                        <a
                          href={formatWhatsAppUrl(phone)}
                          target="_blank"
                          rel="noopener noreferrer"
                          className="flex-1 inline-flex items-center justify-center gap-2 px-3.5 py-2 text-xs font-semibold rounded-lg bg-[#15803D] text-white hover:bg-[#166534] transition-colors"
                        >
                          <MessageCircle className="w-3.5 h-3.5" aria-hidden="true" />
                          {t.contact.whatsappChat}
                        </a>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="pt-4 border-t border-white/10 space-y-3">
                <div className="flex items-start gap-3">
                  <MapPin className="w-5 h-5 text-[#D99B26] shrink-0 mt-0.5" aria-hidden="true" />
                  <p className="text-sm text-slate-200 leading-relaxed">
                    {lang === 'bn' ? settings.addressBn : settings.addressEn}
                  </p>
                </div>
                <a
                  href={getNarsingdiMapsSearchUrl()}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 text-sm font-semibold text-[#D99B26] hover:underline"
                >
                  {t.location.openGoogleMaps}
                  <ExternalLink className="w-4 h-4" aria-hidden="true" />
                </a>
              </div>
            </div>
          </div>

          {/* Contact Inquiry Form */}
          <div className="lg:col-span-7 bg-[#F6F7FA] border border-slate-200 rounded-xl p-6 sm:p-8">
            <h3 className="text-xl font-bold text-[#0F2342] mb-6">{t.contact.formTitle}</h3>

            {sent && (
              <div
                role="status"
                className="mb-6 p-4 rounded-lg bg-emerald-50 border border-emerald-200 flex items-start gap-3 text-emerald-900 text-sm"
              >
                <CheckCircle2 className="w-5 h-5 text-emerald-700 shrink-0 mt-0.5" aria-hidden="true" />
                <span>{t.contact.inquirySuccess}</span>
              </div>
            )}

            {errorMsg && (
              <div
                role="alert"
                className="mb-6 p-4 rounded-lg bg-rose-50 border border-rose-200 text-rose-900 text-sm"
              >
                {errorMsg}
              </div>
            )}

            <form onSubmit={handleSubmit(onSubmit)} noValidate className="space-y-5">
              <div className="grid grid-cols-1 sm:grid-cols-2 gap-5">
                <div>
                  <label htmlFor="inq-senderName" className="block text-sm font-medium text-[#0F2342] mb-1.5">
                    {t.contact.senderName} *
                  </label>
                  <input
                    id="inq-senderName"
                    type="text"
                    {...register('senderName')}
                    className="w-full px-3.5 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-[#0F2342]"
                  />
                  {errors.senderName && (
                    <p className="mt-1 text-xs text-rose-600">{errors.senderName.message}</p>
                  )}
                </div>

                <div>
                  <label htmlFor="inq-phone" className="block text-sm font-medium text-[#0F2342] mb-1.5">
                    {t.contact.phone} *
                  </label>
                  <input
                    id="inq-phone"
                    type="tel"
                    placeholder="01XXXXXXXXX"
                    {...register('phone')}
                    className="w-full px-3.5 py-2.5 text-sm font-mono-tabular bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-[#0F2342]"
                  />
                  {errors.phone && (
                    <p className="mt-1 text-xs text-rose-600">{errors.phone.message}</p>
                  )}
                </div>
              </div>

              <div>
                <label htmlFor="inq-subject" className="block text-sm font-medium text-[#0F2342] mb-1.5">
                  {t.contact.subject} *
                </label>
                <input
                  id="inq-subject"
                  type="text"
                  {...register('subject')}
                  className="w-full px-3.5 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-[#0F2342]"
                />
                {errors.subject && (
                  <p className="mt-1 text-xs text-rose-600">{errors.subject.message}</p>
                )}
              </div>

              <div>
                <label htmlFor="inq-message" className="block text-sm font-medium text-[#0F2342] mb-1.5">
                  {t.contact.message} *
                </label>
                <textarea
                  id="inq-message"
                  rows={4}
                  {...register('message')}
                  className="w-full px-3.5 py-2.5 text-sm bg-white border border-slate-300 rounded-lg focus:outline-none focus:border-[#0F2342]"
                />
                {errors.message && (
                  <p className="mt-1 text-xs text-rose-600">{errors.message.message}</p>
                )}
              </div>

              <button
                type="submit"
                disabled={isSubmitting}
                className="inline-flex items-center justify-center px-6 py-3 text-sm font-semibold text-[#0F2342] bg-[#D99B26] hover:bg-[#c58a1c] rounded-lg transition-colors duration-150 disabled:opacity-60"
              >
                {isSubmitting ? t.contact.sending : t.contact.sendInquiry}
              </button>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
}
