import React, { createContext, useCallback, useContext, useEffect, useState } from 'react';
import { onAuthStateChanged, signInWithPopup, signOut, type User } from 'firebase/auth';
import {
  DEFAULT_FACILITIES,
  DEFAULT_GALLERY,
  DEFAULT_ROOM_IMAGES,
  DEFAULT_ROOMS,
  DEFAULT_SETTINGS,
} from '../data/defaults';
import { COPY, type CopyBundle } from '../data/i18n';
import { auth, googleProvider, verifyFirestoreConnection } from '../lib/firebase';
import {
  checkIsUserAdmin,
  ensureAdminSeededAndSynced,
  fetchPublicWebsiteData,
} from '../services/hostelService';
import type {
  FacilityItem,
  GalleryItem,
  Language,
  Room,
  RoomImage,
  TestimonialItem,
  WebsiteSettings,
} from '../types/hostel';

interface AppContextValue {
  lang: Language;
  setLang: (lang: Language) => void;
  toggleLang: () => void;
  t: CopyBundle;
  settings: WebsiteSettings;
  rooms: Room[];
  roomImages: RoomImage[];
  facilities: FacilityItem[];
  gallery: GalleryItem[];
  testimonials: TestimonialItem[];
  seededInFirestore: boolean;
  loadingData: boolean;
  user: User | null;
  authReady: boolean;
  isAdmin: boolean;
  adminChecking: boolean;
  signInWithGoogle: () => Promise<void>;
  logout: () => Promise<void>;
  refreshPublicData: () => Promise<void>;
}

const AppContext = createContext<AppContextValue | null>(null);

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [lang, setLangState] = useState<Language>(() => {
    try {
      const saved = localStorage.getItem('bidyanidhi_lang');
      return saved === 'en' ? 'en' : 'bn';
    } catch {
      return 'bn';
    }
  });

  const [settings, setSettings] = useState<WebsiteSettings>(DEFAULT_SETTINGS);
  const [rooms, setRooms] = useState<Room[]>(DEFAULT_ROOMS);
  const [roomImages, setRoomImages] = useState<RoomImage[]>(DEFAULT_ROOM_IMAGES);
  const [facilities, setFacilities] = useState<FacilityItem[]>(DEFAULT_FACILITIES);
  const [gallery, setGallery] = useState<GalleryItem[]>(DEFAULT_GALLERY);
  const [testimonials, setTestimonials] = useState<TestimonialItem[]>([]);
  const [seededInFirestore, setSeededInFirestore] = useState(false);
  const [loadingData, setLoadingData] = useState(true);

  const [user, setUser] = useState<User | null>(null);
  const [authReady, setAuthReady] = useState(false);
  const [isAdmin, setIsAdmin] = useState(false);
  const [adminChecking, setAdminChecking] = useState(false);

  const setLang = useCallback((next: Language) => {
    setLangState(next);
    document.documentElement.lang = next;
    try {
      localStorage.setItem('bidyanidhi_lang', next);
    } catch {
      // ignore storage quota errors
    }
  }, []);

  const toggleLang = useCallback(() => {
    setLang(lang === 'bn' ? 'en' : 'bn');
  }, [lang, setLang]);

  const refreshPublicData = useCallback(async () => {
    setLoadingData(true);
    try {
      const data = await fetchPublicWebsiteData();
      setSettings(data.settings);
      setRooms(data.rooms);
      setRoomImages(data.roomImages);
      setFacilities(data.facilities);
      setGallery(data.gallery);
      setTestimonials(data.testimonials);
      setSeededInFirestore(data.seededInFirestore);
    } finally {
      setLoadingData(false);
    }
  }, []);

  useEffect(() => {
    document.documentElement.lang = lang;
    verifyFirestoreConnection();
    refreshPublicData();
  }, [lang, refreshPublicData]);

  // Keep <title> and <meta description> synced with admin-configured SEO settings
  useEffect(() => {
    if (settings.seoTitle) {
      document.title = settings.seoTitle;
    }
    const metaDesc = document.querySelector('meta[name="description"]');
    if (metaDesc && settings.seoDescription) {
      metaDesc.setAttribute('content', settings.seoDescription);
    }
  }, [settings.seoTitle, settings.seoDescription]);

  useEffect(() => {
    const unsub = onAuthStateChanged(auth, async (nextUser) => {
      setUser(nextUser);
      if (nextUser) {
        setAdminChecking(true);
        const adminOk = await checkIsUserAdmin(
          nextUser.uid,
          nextUser.email,
          nextUser.emailVerified
        );
        setIsAdmin(adminOk);
        if (adminOk) {
          try {
            await ensureAdminSeededAndSynced();
            await refreshPublicData();
          } catch (err) {
            console.error('Admin initial seed/sync failed:', err);
          }
        }
        setAdminChecking(false);
      } else {
        setIsAdmin(false);
        setAdminChecking(false);
      }
      setAuthReady(true);
    });
    return () => unsub();
  }, [refreshPublicData]);

  const signInWithGoogle = useCallback(async () => {
    await signInWithPopup(auth, googleProvider);
  }, []);

  const logout = useCallback(async () => {
    await signOut(auth);
  }, []);

  return (
    <AppContext.Provider
      value={{
        lang,
        setLang,
        toggleLang,
        t: COPY[lang],
        settings,
        rooms,
        roomImages,
        facilities,
        gallery,
        testimonials,
        seededInFirestore,
        loadingData,
        user,
        authReady,
        isAdmin,
        adminChecking,
        signInWithGoogle,
        logout,
        refreshPublicData,
      }}
    >
      {children}
    </AppContext.Provider>
  );
}

export function useApp(): AppContextValue {
  const ctx = useContext(AppContext);
  if (!ctx) {
    throw new Error('useApp must be used inside AppProvider');
  }
  return ctx;
}
